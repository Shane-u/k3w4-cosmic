export declare type HRMsgCollaborationModule = $.kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationModule;
export declare const HRMsgCollaborationModule: $.kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationModule_C;
export declare type HRMsgCollaborationServiceHelper = $.kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationServiceHelper;
export declare const HRMsgCollaborationServiceHelper: $.kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationServiceHelper_C;
