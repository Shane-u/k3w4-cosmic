export const LCSCostCenterModule = $.type("kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterModule");
export const LCSCostCenterServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterServiceHelper");
