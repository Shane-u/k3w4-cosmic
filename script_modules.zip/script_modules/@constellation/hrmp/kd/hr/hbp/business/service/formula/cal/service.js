export const AbsHRMPCalcService = $.type("kd.hr.hbp.business.service.formula.cal.service.AbsHRMPCalcService");
