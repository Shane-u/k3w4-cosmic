export declare type HisAttachmentDataBo = $.kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentDataBo;
export declare const HisAttachmentDataBo: $.kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentDataBo_C;
export declare type HisAttachmentParamBo = $.kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentParamBo;
export declare const HisAttachmentParamBo: $.kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentParamBo_C;
