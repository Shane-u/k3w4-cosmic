export declare type IAdminGroupListSubPlugin = $.kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupListSubPlugin;
export declare const IAdminGroupListSubPlugin: $.kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupListSubPlugin;
export declare type IAdminGroupPermSubPlugin = $.kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupPermSubPlugin;
export declare const IAdminGroupPermSubPlugin: $.kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupPermSubPlugin;
