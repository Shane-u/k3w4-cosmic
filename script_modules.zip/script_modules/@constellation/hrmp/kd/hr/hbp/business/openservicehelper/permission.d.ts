export declare type HRPermissionModule = $.kd.hr.hbp.business.openservicehelper.permission.HRPermissionModule;
export declare const HRPermissionModule: $.kd.hr.hbp.business.openservicehelper.permission.HRPermissionModule_C;
export declare type HRPermissionServiceHelper = $.kd.hr.hbp.business.openservicehelper.permission.HRPermissionServiceHelper;
export declare const HRPermissionServiceHelper: $.kd.hr.hbp.business.openservicehelper.permission.HRPermissionServiceHelper_C;
