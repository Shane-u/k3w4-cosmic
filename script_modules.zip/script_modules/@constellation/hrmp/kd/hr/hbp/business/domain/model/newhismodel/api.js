export const HisBatchDiscardApiBo = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.HisBatchDiscardApiBo");
export const HisDiscardApiBo = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.HisDiscardApiBo");
