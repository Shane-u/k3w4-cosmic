export declare type IPermRuleMatchPlugin = $.kd.hr.hbp.business.extpoint.permission.dyna.IPermRuleMatchPlugin;
export declare const IPermRuleMatchPlugin: $.kd.hr.hbp.business.extpoint.permission.dyna.IPermRuleMatchPlugin;
