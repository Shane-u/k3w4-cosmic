export const IPermRuleMatchPlugin = $.type("kd.hr.hbp.business.extpoint.permission.dyna.IPermRuleMatchPlugin");
