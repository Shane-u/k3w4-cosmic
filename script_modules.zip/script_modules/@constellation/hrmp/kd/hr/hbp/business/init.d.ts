export declare type ITransferConfPostMicroService = $.kd.hr.hbp.business.init.ITransferConfPostMicroService;
export declare const ITransferConfPostMicroService: $.kd.hr.hbp.business.init.ITransferConfPostMicroService;
