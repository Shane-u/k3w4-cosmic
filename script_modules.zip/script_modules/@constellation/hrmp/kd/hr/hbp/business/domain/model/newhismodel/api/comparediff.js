export const CompareDiffApiBatchInputParam = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiBatchInputParam");
export const CompareDiffApiInputParam = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiInputParam");
export const CompareDiffApiOutPutParam = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiOutPutParam");
