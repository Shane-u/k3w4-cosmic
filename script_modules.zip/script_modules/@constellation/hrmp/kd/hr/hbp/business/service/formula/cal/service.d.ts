export declare type AbsHRMPCalcService = $.kd.hr.hbp.business.service.formula.cal.service.AbsHRMPCalcService;
export declare const AbsHRMPCalcService: $.kd.hr.hbp.business.service.formula.cal.service.AbsHRMPCalcService_C;
