export const HRBaseDataModelModule = $.type("kd.hr.hbp.business.openservicehelper.basedata.HRBaseDataModelModule");
