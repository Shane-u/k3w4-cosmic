export const AdminOrgServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.odc.AdminOrgServiceHelper");
export const HROdcModule = $.type("kd.hr.hbp.business.openservicehelper.odc.HROdcModule");
export const PositionServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.odc.PositionServiceHelper");
