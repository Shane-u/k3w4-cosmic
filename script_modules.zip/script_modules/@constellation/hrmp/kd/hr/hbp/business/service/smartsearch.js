export const HRSmartSearchService = $.type("kd.hr.hbp.business.service.smartsearch.HRSmartSearchService");
export const SearchSceneService = $.type("kd.hr.hbp.business.service.smartsearch.SearchSceneService");
