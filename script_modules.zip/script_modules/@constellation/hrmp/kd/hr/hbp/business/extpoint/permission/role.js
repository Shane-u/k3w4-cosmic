export const IExportRolePermCusPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.IExportRolePermCusPlugin");
export const IMemAssignRoleCusPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.IMemAssignRoleCusPlugin");
export const IRoleAssignMemCusPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.IRoleAssignMemCusPlugin");
export const IRoleDimF7CustomFilterPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.IRoleDimF7CustomFilterPlugin");
export const IRoleMemCusListPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.IRoleMemCusListPlugin");
export const ISchemeParamRuleCustomFilterPlugin = $.type("kd.hr.hbp.business.extpoint.permission.role.ISchemeParamRuleCustomFilterPlugin");
