export const HisEnableParamBo = $.type("kd.hr.hbp.business.domain.model.newhismodel.enable.HisEnableParamBo");
