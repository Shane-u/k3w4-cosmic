export declare type FormulaParseService = $.kd.hr.hbp.business.service.formula.FormulaParseService;
export declare const FormulaParseService: $.kd.hr.hbp.business.service.formula.FormulaParseService_C;
export declare type HRFormulaPlatformModule = $.kd.hr.hbp.business.service.formula.HRFormulaPlatformModule;
export declare const HRFormulaPlatformModule: $.kd.hr.hbp.business.service.formula.HRFormulaPlatformModule_C;
