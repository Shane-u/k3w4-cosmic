export const HRPermissionModule = $.type("kd.hr.hbp.business.openservicehelper.permission.HRPermissionModule");
export const HRPermissionServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.permission.HRPermissionServiceHelper");
