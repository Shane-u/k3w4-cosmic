export const HRQueryEntityModule = $.type("kd.hr.hbp.business.openservicehelper.multientityquery.HRQueryEntityModule");
