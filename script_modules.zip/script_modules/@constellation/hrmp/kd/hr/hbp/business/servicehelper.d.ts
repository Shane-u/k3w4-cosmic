export declare type HRQueryEntityHelper = $.kd.hr.hbp.business.servicehelper.HRQueryEntityHelper;
export declare const HRQueryEntityHelper: $.kd.hr.hbp.business.servicehelper.HRQueryEntityHelper_C;
