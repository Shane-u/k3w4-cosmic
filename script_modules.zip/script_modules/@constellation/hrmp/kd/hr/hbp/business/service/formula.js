export const FormulaParseService = $.type("kd.hr.hbp.business.service.formula.FormulaParseService");
export const HRFormulaPlatformModule = $.type("kd.hr.hbp.business.service.formula.HRFormulaPlatformModule");
