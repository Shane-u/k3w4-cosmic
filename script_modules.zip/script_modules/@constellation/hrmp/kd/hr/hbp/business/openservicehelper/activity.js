export const HRActivityModule = $.type("kd.hr.hbp.business.openservicehelper.activity.HRActivityModule");
export const HRActivityServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.activity.HRActivityServiceHelper");
