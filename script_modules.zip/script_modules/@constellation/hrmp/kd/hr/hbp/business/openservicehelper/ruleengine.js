export const HRRuleEngineModule = $.type("kd.hr.hbp.business.openservicehelper.ruleengine.HRRuleEngineModule");
export const RuleEngineServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.ruleengine.RuleEngineServiceHelper");
