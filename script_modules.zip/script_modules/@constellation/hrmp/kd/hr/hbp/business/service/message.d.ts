export declare type IHRMsgTplService = $.kd.hr.hbp.business.service.message.IHRMsgTplService;
export declare const IHRMsgTplService: $.kd.hr.hbp.business.service.message.IHRMsgTplService;
