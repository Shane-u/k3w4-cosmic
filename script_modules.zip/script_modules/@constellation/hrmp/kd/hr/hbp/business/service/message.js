export const IHRMsgTplService = $.type("kd.hr.hbp.business.service.message.IHRMsgTplService");
