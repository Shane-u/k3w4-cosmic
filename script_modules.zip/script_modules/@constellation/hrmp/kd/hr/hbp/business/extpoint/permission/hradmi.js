export const IAdminGroupListSubPlugin = $.type("kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupListSubPlugin");
export const IAdminGroupPermSubPlugin = $.type("kd.hr.hbp.business.extpoint.permission.hradmi.IAdminGroupPermSubPlugin");
