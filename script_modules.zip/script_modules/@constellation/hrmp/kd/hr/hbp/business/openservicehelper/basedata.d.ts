export declare type HRBaseDataModelModule = $.kd.hr.hbp.business.openservicehelper.basedata.HRBaseDataModelModule;
export declare const HRBaseDataModelModule: $.kd.hr.hbp.business.openservicehelper.basedata.HRBaseDataModelModule_C;
