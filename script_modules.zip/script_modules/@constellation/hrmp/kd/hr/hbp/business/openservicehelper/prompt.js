export const HRPromptModule = $.type("kd.hr.hbp.business.openservicehelper.prompt.HRPromptModule");
export const PromptServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.prompt.PromptServiceHelper");
