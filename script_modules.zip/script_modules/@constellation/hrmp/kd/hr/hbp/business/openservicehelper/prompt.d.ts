export declare type HRPromptModule = $.kd.hr.hbp.business.openservicehelper.prompt.HRPromptModule;
export declare const HRPromptModule: $.kd.hr.hbp.business.openservicehelper.prompt.HRPromptModule_C;
export declare type PromptServiceHelper = $.kd.hr.hbp.business.openservicehelper.prompt.PromptServiceHelper;
export declare const PromptServiceHelper: $.kd.hr.hbp.business.openservicehelper.prompt.PromptServiceHelper_C;
