export declare type HRRuleEngineModule = $.kd.hr.hbp.business.openservicehelper.ruleengine.HRRuleEngineModule;
export declare const HRRuleEngineModule: $.kd.hr.hbp.business.openservicehelper.ruleengine.HRRuleEngineModule_C;
export declare type RuleEngineServiceHelper = $.kd.hr.hbp.business.openservicehelper.ruleengine.RuleEngineServiceHelper;
export declare const RuleEngineServiceHelper: $.kd.hr.hbp.business.openservicehelper.ruleengine.RuleEngineServiceHelper_C;
