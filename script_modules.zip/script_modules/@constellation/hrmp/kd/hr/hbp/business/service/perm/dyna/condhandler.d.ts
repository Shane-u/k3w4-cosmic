export declare type IDynaCondParser = $.kd.hr.hbp.business.service.perm.dyna.condhandler.IDynaCondParser;
export declare const IDynaCondParser: $.kd.hr.hbp.business.service.perm.dyna.condhandler.IDynaCondParser;
