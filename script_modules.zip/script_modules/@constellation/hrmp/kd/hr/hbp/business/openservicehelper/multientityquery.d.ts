export declare type HRQueryEntityModule = $.kd.hr.hbp.business.openservicehelper.multientityquery.HRQueryEntityModule;
export declare const HRQueryEntityModule: $.kd.hr.hbp.business.openservicehelper.multientityquery.HRQueryEntityModule_C;
