export const AbstractSortingArrayService = $.type("kd.hr.hbp.business.application.impl.common.AbstractSortingArrayService");
export const CompareDiffController = $.type("kd.hr.hbp.business.application.impl.common.CompareDiffController");
export const DynamicObjectCommonService = $.type("kd.hr.hbp.business.application.impl.common.DynamicObjectCommonService");
