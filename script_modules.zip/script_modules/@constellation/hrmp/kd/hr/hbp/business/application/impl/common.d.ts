export declare type AbstractSortingArrayService = $.kd.hr.hbp.business.application.impl.common.AbstractSortingArrayService;
export declare const AbstractSortingArrayService: $.kd.hr.hbp.business.application.impl.common.AbstractSortingArrayService_C;
export declare type CompareDiffController = $.kd.hr.hbp.business.application.impl.common.CompareDiffController;
export declare const CompareDiffController: $.kd.hr.hbp.business.application.impl.common.CompareDiffController_C;
export declare type DynamicObjectCommonService = $.kd.hr.hbp.business.application.impl.common.DynamicObjectCommonService;
export declare const DynamicObjectCommonService: $.kd.hr.hbp.business.application.impl.common.DynamicObjectCommonService_C;
