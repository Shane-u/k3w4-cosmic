export declare type HRSmartSearchService = $.kd.hr.hbp.business.service.smartsearch.HRSmartSearchService;
export declare const HRSmartSearchService: $.kd.hr.hbp.business.service.smartsearch.HRSmartSearchService_C;
export declare type SearchSceneService = $.kd.hr.hbp.business.service.smartsearch.SearchSceneService;
export declare const SearchSceneService: $.kd.hr.hbp.business.service.smartsearch.SearchSceneService_C;
