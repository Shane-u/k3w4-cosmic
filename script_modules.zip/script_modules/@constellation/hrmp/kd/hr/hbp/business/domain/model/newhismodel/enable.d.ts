export declare type HisEnableParamBo = $.kd.hr.hbp.business.domain.model.newhismodel.enable.HisEnableParamBo;
export declare const HisEnableParamBo: $.kd.hr.hbp.business.domain.model.newhismodel.enable.HisEnableParamBo_C;
