export const IDynaCondParser = $.type("kd.hr.hbp.business.service.perm.dyna.condhandler.IDynaCondParser");
