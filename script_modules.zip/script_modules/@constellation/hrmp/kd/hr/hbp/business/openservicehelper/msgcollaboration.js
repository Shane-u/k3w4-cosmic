export const HRMsgCollaborationModule = $.type("kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationModule");
export const HRMsgCollaborationServiceHelper = $.type("kd.hr.hbp.business.openservicehelper.msgcollaboration.HRMsgCollaborationServiceHelper");
