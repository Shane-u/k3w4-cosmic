export const HisAttachmentDataBo = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentDataBo");
export const HisAttachmentParamBo = $.type("kd.hr.hbp.business.domain.model.newhismodel.api.attachment.HisAttachmentParamBo");
