export declare type AdminOrgServiceHelper = $.kd.hr.hbp.business.openservicehelper.odc.AdminOrgServiceHelper;
export declare const AdminOrgServiceHelper: $.kd.hr.hbp.business.openservicehelper.odc.AdminOrgServiceHelper_C;
export declare type HROdcModule = $.kd.hr.hbp.business.openservicehelper.odc.HROdcModule;
export declare const HROdcModule: $.kd.hr.hbp.business.openservicehelper.odc.HROdcModule_C;
export declare type PositionServiceHelper = $.kd.hr.hbp.business.openservicehelper.odc.PositionServiceHelper;
export declare const PositionServiceHelper: $.kd.hr.hbp.business.openservicehelper.odc.PositionServiceHelper_C;
