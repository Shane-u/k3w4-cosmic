export declare type HRActivityModule = $.kd.hr.hbp.business.openservicehelper.activity.HRActivityModule;
export declare const HRActivityModule: $.kd.hr.hbp.business.openservicehelper.activity.HRActivityModule_C;
export declare type HRActivityServiceHelper = $.kd.hr.hbp.business.openservicehelper.activity.HRActivityServiceHelper;
export declare const HRActivityServiceHelper: $.kd.hr.hbp.business.openservicehelper.activity.HRActivityServiceHelper_C;
