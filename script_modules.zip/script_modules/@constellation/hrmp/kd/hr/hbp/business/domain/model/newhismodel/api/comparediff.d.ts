export declare type CompareDiffApiBatchInputParam = $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiBatchInputParam;
export declare const CompareDiffApiBatchInputParam: $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiBatchInputParam_C;
export declare type CompareDiffApiInputParam = $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiInputParam;
export declare const CompareDiffApiInputParam: $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiInputParam_C;
export declare type CompareDiffApiOutPutParam = $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiOutPutParam;
export declare const CompareDiffApiOutPutParam: $.kd.hr.hbp.business.domain.model.newhismodel.api.comparediff.CompareDiffApiOutPutParam_C;
