export declare type HRHisModelModule = $.kd.hr.hbp.business.application.impl.newhismodel.HRHisModelModule;
export declare const HRHisModelModule: $.kd.hr.hbp.business.application.impl.newhismodel.HRHisModelModule_C;
export declare type HisModelAttachController = $.kd.hr.hbp.business.application.impl.newhismodel.HisModelAttachController;
export declare const HisModelAttachController: $.kd.hr.hbp.business.application.impl.newhismodel.HisModelAttachController_C;
export declare type HisModelController = $.kd.hr.hbp.business.application.impl.newhismodel.HisModelController;
export declare const HisModelController: $.kd.hr.hbp.business.application.impl.newhismodel.HisModelController_C;
export declare type HisModelInitController = $.kd.hr.hbp.business.application.impl.newhismodel.HisModelInitController;
export declare const HisModelInitController: $.kd.hr.hbp.business.application.impl.newhismodel.HisModelInitController_C;
