export declare type HisBatchDiscardApiBo = $.kd.hr.hbp.business.domain.model.newhismodel.api.HisBatchDiscardApiBo;
export declare const HisBatchDiscardApiBo: $.kd.hr.hbp.business.domain.model.newhismodel.api.HisBatchDiscardApiBo_C;
export declare type HisDiscardApiBo = $.kd.hr.hbp.business.domain.model.newhismodel.api.HisDiscardApiBo;
export declare const HisDiscardApiBo: $.kd.hr.hbp.business.domain.model.newhismodel.api.HisDiscardApiBo_C;
