export const HRQueryEntityHelper = $.type("kd.hr.hbp.business.servicehelper.HRQueryEntityHelper");
