export declare type LCSCostCenterModule = $.kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterModule;
export declare const LCSCostCenterModule: $.kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterModule_C;
export declare type LCSCostCenterServiceHelper = $.kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterServiceHelper;
export declare const LCSCostCenterServiceHelper: $.kd.hr.hbp.business.openservicehelper.lcs.LCSCostCenterServiceHelper_C;
