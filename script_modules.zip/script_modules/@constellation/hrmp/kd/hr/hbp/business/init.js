export const ITransferConfPostMicroService = $.type("kd.hr.hbp.business.init.ITransferConfPostMicroService");
