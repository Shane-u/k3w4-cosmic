export const HRHisModelModule = $.type("kd.hr.hbp.business.application.impl.newhismodel.HRHisModelModule");
export const HisModelAttachController = $.type("kd.hr.hbp.business.application.impl.newhismodel.HisModelAttachController");
export const HisModelController = $.type("kd.hr.hbp.business.application.impl.newhismodel.HisModelController");
export const HisModelInitController = $.type("kd.hr.hbp.business.application.impl.newhismodel.HisModelInitController");
