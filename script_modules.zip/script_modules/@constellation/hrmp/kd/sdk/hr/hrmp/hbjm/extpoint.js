export const HROdcModule = $.type("kd.sdk.hr.hrmp.hbjm.extpoint.HROdcModule");
export const IJobTreeSortConditionExtend = $.type("kd.sdk.hr.hrmp.hbjm.extpoint.IJobTreeSortConditionExtend");
