export declare type HROdcModule = $.kd.sdk.hr.hrmp.haos.extpoint.HROdcModule;
export declare const HROdcModule: $.kd.sdk.hr.hrmp.haos.extpoint.HROdcModule_C;
export declare type IStaffExtDimFilterExtend = $.kd.sdk.hr.hrmp.haos.extpoint.IStaffExtDimFilterExtend;
export declare const IStaffExtDimFilterExtend: $.kd.sdk.hr.hrmp.haos.extpoint.IStaffExtDimFilterExtend;
export declare type IStaffRuleConfigExtend = $.kd.sdk.hr.hrmp.haos.extpoint.IStaffRuleConfigExtend;
export declare const IStaffRuleConfigExtend: $.kd.sdk.hr.hrmp.haos.extpoint.IStaffRuleConfigExtend;
