export const HROdcModule = $.type("kd.sdk.hr.hrmp.haos.extpoint.HROdcModule");
export const IStaffExtDimFilterExtend = $.type("kd.sdk.hr.hrmp.haos.extpoint.IStaffExtDimFilterExtend");
export const IStaffRuleConfigExtend = $.type("kd.sdk.hr.hrmp.haos.extpoint.IStaffRuleConfigExtend");
