export declare type HRHdtcModule = $.kd.sdk.hr.hrmp.hrdi.HRHdtcModule;
export declare const HRHdtcModule: $.kd.sdk.hr.hrmp.hrdi.HRHdtcModule_C;
export declare type IHRCommonIntegrationService = $.kd.sdk.hr.hrmp.hrdi.IHRCommonIntegrationService;
export declare const IHRCommonIntegrationService: $.kd.sdk.hr.hrmp.hrdi.IHRCommonIntegrationService;
