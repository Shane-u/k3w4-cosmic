export const HRHdtcModule = $.type("kd.sdk.hr.hrmp.hrdi.HRHdtcModule");
export const IHRCommonIntegrationService = $.type("kd.sdk.hr.hrmp.hrdi.IHRCommonIntegrationService");
