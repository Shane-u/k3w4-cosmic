export declare type HROdcModule = $.kd.sdk.hr.hrmp.hbjm.extpoint.HROdcModule;
export declare const HROdcModule: $.kd.sdk.hr.hrmp.hbjm.extpoint.HROdcModule_C;
export declare type IJobTreeSortConditionExtend = $.kd.sdk.hr.hrmp.hbjm.extpoint.IJobTreeSortConditionExtend;
export declare const IJobTreeSortConditionExtend: $.kd.sdk.hr.hrmp.hbjm.extpoint.IJobTreeSortConditionExtend;
