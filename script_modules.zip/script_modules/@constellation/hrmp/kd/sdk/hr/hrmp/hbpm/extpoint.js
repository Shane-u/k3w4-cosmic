export const HROdcModule = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.HROdcModule");
export const IBosPositionValidateServiceExt = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.IBosPositionValidateServiceExt");
export const IPositionCompareEntryServiceExtend = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.IPositionCompareEntryServiceExtend");
export const IPositionF7OrgTreeOrgIdsServiceExtend = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.IPositionF7OrgTreeOrgIdsServiceExtend");
export const IPositionSkipValidateServiceExtend = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.IPositionSkipValidateServiceExtend");
export const IValidatorExtend = $.type("kd.sdk.hr.hrmp.hbpm.extpoint.IValidatorExtend");
