/// <reference types="./kd/sdk/hdtc/hrdi/adaptor/api" />
/// <reference types="./kd/sdk/hdtc/hrdi/adaptor/extend" />
/// <reference types="./kd/sdk/hdtc/hrdi" />
/// <reference types="./kd/sdk/hdtc/hrdi/adaptor/service" />
/// <reference types="./index" />
