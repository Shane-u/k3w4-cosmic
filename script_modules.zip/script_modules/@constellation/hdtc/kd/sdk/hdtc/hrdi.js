export const SdkHdtcHrdiModule = $.type("kd.sdk.hdtc.hrdi.SdkHdtcHrdiModule");
