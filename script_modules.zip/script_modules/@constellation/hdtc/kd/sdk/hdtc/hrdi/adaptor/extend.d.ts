/// <reference types="../../../../../index" />
export declare type IBaseDataBeforeInvokeApiExtend = $.kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataBeforeInvokeApiExtend;
export declare const IBaseDataBeforeInvokeApiExtend: $.kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataBeforeInvokeApiExtend;
export declare type IBaseDataUniqueFieldExtend = $.kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataUniqueFieldExtend;
export declare const IBaseDataUniqueFieldExtend: $.kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataUniqueFieldExtend;
export declare type IBizPersonDataMappingExtendUpdate = $.kd.sdk.hdtc.hrdi.adaptor.extend.IBizPersonDataMappingExtendUpdate;
export declare const IBizPersonDataMappingExtendUpdate: $.kd.sdk.hdtc.hrdi.adaptor.extend.IBizPersonDataMappingExtendUpdate;
export declare type IBizSyncSceneExtendAdaptor = $.kd.sdk.hdtc.hrdi.adaptor.extend.IBizSyncSceneExtendAdaptor;
export declare const IBizSyncSceneExtendAdaptor: $.kd.sdk.hdtc.hrdi.adaptor.extend.IBizSyncSceneExtendAdaptor;
export declare type IMidTableDataExtendValidator = $.kd.sdk.hdtc.hrdi.adaptor.extend.IMidTableDataExtendValidator;
export declare const IMidTableDataExtendValidator: $.kd.sdk.hdtc.hrdi.adaptor.extend.IMidTableDataExtendValidator;
export declare type IPersonMainEntityExtend = $.kd.sdk.hdtc.hrdi.adaptor.extend.IPersonMainEntityExtend;
export declare const IPersonMainEntityExtend: $.kd.sdk.hdtc.hrdi.adaptor.extend.IPersonMainEntityExtend;
