export const IBizSyncSceneAdaptor = $.type("kd.sdk.hdtc.hrdi.adaptor.api.IBizSyncSceneAdaptor");
