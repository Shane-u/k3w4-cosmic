/// <reference types="../../../../../index" />
export declare type IBizSyncSceneAdaptor = $.kd.sdk.hdtc.hrdi.adaptor.api.IBizSyncSceneAdaptor;
export declare const IBizSyncSceneAdaptor: $.kd.sdk.hdtc.hrdi.adaptor.api.IBizSyncSceneAdaptor;
