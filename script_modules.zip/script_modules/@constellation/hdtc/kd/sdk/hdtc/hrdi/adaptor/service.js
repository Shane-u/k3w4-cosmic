export const HrdiBizDataSyncServiceHelper = $.type("kd.sdk.hdtc.hrdi.adaptor.service.HrdiBizDataSyncServiceHelper");
