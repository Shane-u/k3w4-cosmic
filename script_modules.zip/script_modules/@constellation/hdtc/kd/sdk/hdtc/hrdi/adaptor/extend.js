export const IBaseDataBeforeInvokeApiExtend = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataBeforeInvokeApiExtend");
export const IBaseDataUniqueFieldExtend = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IBaseDataUniqueFieldExtend");
export const IBizPersonDataMappingExtendUpdate = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IBizPersonDataMappingExtendUpdate");
export const IBizSyncSceneExtendAdaptor = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IBizSyncSceneExtendAdaptor");
export const IMidTableDataExtendValidator = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IMidTableDataExtendValidator");
export const IPersonMainEntityExtend = $.type("kd.sdk.hdtc.hrdi.adaptor.extend.IPersonMainEntityExtend");
