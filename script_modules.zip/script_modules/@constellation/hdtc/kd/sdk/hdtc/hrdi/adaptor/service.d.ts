/// <reference types="../../../../../index" />
export declare type HrdiBizDataSyncServiceHelper = $.kd.sdk.hdtc.hrdi.adaptor.service.HrdiBizDataSyncServiceHelper;
export declare const HrdiBizDataSyncServiceHelper: $.kd.sdk.hdtc.hrdi.adaptor.service.HrdiBizDataSyncServiceHelper_C;
