/// <reference types="../../../index" />
export declare type SdkHdtcHrdiModule = $.kd.sdk.hdtc.hrdi.SdkHdtcHrdiModule;
export declare const SdkHdtcHrdiModule: $.kd.sdk.hdtc.hrdi.SdkHdtcHrdiModule_C;
