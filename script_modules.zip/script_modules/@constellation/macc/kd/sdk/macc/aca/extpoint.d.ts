export declare type IActCostCalcLvlPlugin = $.kd.sdk.macc.aca.extpoint.IActCostCalcLvlPlugin;
export declare const IActCostCalcLvlPlugin: $.kd.sdk.macc.aca.extpoint.IActCostCalcLvlPlugin;
export declare type IActCostCalcPlugin = $.kd.sdk.macc.aca.extpoint.IActCostCalcPlugin;
export declare const IActCostCalcPlugin: $.kd.sdk.macc.aca.extpoint.IActCostCalcPlugin;
