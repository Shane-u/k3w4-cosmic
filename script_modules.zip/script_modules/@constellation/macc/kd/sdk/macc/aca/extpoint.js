export const IActCostCalcLvlPlugin = $.type("kd.sdk.macc.aca.extpoint.IActCostCalcLvlPlugin");
export const IActCostCalcPlugin = $.type("kd.sdk.macc.aca.extpoint.IActCostCalcPlugin");
