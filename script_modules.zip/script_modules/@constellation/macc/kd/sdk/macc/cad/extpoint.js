export const IDealMatCostInfoAfterUpdate = $.type("kd.sdk.macc.cad.extpoint.IDealMatCostInfoAfterUpdate");
