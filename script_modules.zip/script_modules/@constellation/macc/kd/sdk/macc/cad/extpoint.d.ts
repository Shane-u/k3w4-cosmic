export declare type IDealMatCostInfoAfterUpdate = $.kd.sdk.macc.cad.extpoint.IDealMatCostInfoAfterUpdate;
export declare const IDealMatCostInfoAfterUpdate: $.kd.sdk.macc.cad.extpoint.IDealMatCostInfoAfterUpdate;
