/// <reference types="./kd/sdk/macc/cad/extpoint" />
/// <reference types="./kd/sdk/macc/aca/extpoint" />
/// <reference types="./index" />
