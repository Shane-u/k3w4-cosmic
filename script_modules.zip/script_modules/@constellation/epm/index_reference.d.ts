/// <reference types="./kd/sdk/epm/bgmd/util/model" />
/// <reference types="./kd/sdk/epm/bgmd/util/f7" />
/// <reference types="./index" />
