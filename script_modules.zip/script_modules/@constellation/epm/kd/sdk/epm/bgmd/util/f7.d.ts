export declare type F7Parameter = $.kd.sdk.epm.bgmd.util.f7.F7Parameter;
export declare const F7Parameter: $.kd.sdk.epm.bgmd.util.f7.F7Parameter_C;
export declare type F7Utils = $.kd.sdk.epm.bgmd.util.f7.F7Utils;
export declare const F7Utils: $.kd.sdk.epm.bgmd.util.f7.F7Utils_C;
export declare type F8Utils = $.kd.sdk.epm.bgmd.util.f7.F8Utils;
export declare const F8Utils: $.kd.sdk.epm.bgmd.util.f7.F8Utils_C;
