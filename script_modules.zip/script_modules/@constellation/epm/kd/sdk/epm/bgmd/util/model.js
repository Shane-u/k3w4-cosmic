export const BusinessModelUtils = $.type("kd.sdk.epm.bgmd.util.model.BusinessModelUtils");
export const CubeUtils = $.type("kd.sdk.epm.bgmd.util.model.CubeUtils");
export const DatasetUtils = $.type("kd.sdk.epm.bgmd.util.model.DatasetUtils");
export const DimensionUtils = $.type("kd.sdk.epm.bgmd.util.model.DimensionUtils");
export const MemberUtils = $.type("kd.sdk.epm.bgmd.util.model.MemberUtils");
