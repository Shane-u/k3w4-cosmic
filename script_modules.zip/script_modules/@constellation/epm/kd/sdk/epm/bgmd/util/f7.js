export const F7Parameter = $.type("kd.sdk.epm.bgmd.util.f7.F7Parameter");
export const F7Utils = $.type("kd.sdk.epm.bgmd.util.f7.F7Utils");
export const F8Utils = $.type("kd.sdk.epm.bgmd.util.f7.F8Utils");
