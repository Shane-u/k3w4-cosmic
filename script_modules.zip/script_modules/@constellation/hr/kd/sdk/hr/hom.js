export const SdkHRHomModule = $.type("kd.sdk.hr.hom.SdkHRHomModule");
