export declare type SdkHRHspmModule = $.kd.sdk.hr.hspm.SdkHRHspmModule;
export declare const SdkHRHspmModule: $.kd.sdk.hr.hspm.SdkHRHspmModule_C;
