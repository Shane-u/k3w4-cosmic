export const SdkHRHdmModule = $.type("kd.sdk.hr.hdm.SdkHRHdmModule");
