export const SdkHRHtmModule = $.type("kd.sdk.hr.htm.SdkHRHtmModule");
