export const SdkHRHspmModule = $.type("kd.sdk.hr.hspm.SdkHRHspmModule");
