export const SdkHRHpfsModule = $.type("kd.sdk.hr.hpfs.SdkHRHpfsModule");
