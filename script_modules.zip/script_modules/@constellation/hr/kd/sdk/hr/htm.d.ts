export declare type SdkHRHtmModule = $.kd.sdk.hr.htm.SdkHRHtmModule;
export declare const SdkHRHtmModule: $.kd.sdk.hr.htm.SdkHRHtmModule_C;
