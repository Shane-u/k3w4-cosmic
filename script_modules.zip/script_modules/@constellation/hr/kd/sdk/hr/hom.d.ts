export declare type SdkHRHomModule = $.kd.sdk.hr.hom.SdkHRHomModule;
export declare const SdkHRHomModule: $.kd.sdk.hr.hom.SdkHRHomModule_C;
