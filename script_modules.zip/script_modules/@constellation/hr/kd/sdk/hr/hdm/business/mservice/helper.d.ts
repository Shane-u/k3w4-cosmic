export declare type HDMPartBillServiceHelper = $.kd.sdk.hr.hdm.business.mservice.helper.HDMPartBillServiceHelper;
export declare const HDMPartBillServiceHelper: $.kd.sdk.hr.hdm.business.mservice.helper.HDMPartBillServiceHelper_C;
export declare type HDMRegBillServiceHelper = $.kd.sdk.hr.hdm.business.mservice.helper.HDMRegBillServiceHelper;
export declare const HDMRegBillServiceHelper: $.kd.sdk.hr.hdm.business.mservice.helper.HDMRegBillServiceHelper_C;
export declare type HDMTransferQueryHelper = $.kd.sdk.hr.hdm.business.mservice.helper.HDMTransferQueryHelper;
export declare const HDMTransferQueryHelper: $.kd.sdk.hr.hdm.business.mservice.helper.HDMTransferQueryHelper_C;
export declare type HDMTransferServiceHelper = $.kd.sdk.hr.hdm.business.mservice.helper.HDMTransferServiceHelper;
export declare const HDMTransferServiceHelper: $.kd.sdk.hr.hdm.business.mservice.helper.HDMTransferServiceHelper_C;
