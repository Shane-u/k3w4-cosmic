export const HDMPartBillServiceHelper = $.type("kd.sdk.hr.hdm.business.mservice.helper.HDMPartBillServiceHelper");
export const HDMRegBillServiceHelper = $.type("kd.sdk.hr.hdm.business.mservice.helper.HDMRegBillServiceHelper");
export const HDMTransferQueryHelper = $.type("kd.sdk.hr.hdm.business.mservice.helper.HDMTransferQueryHelper");
export const HDMTransferServiceHelper = $.type("kd.sdk.hr.hdm.business.mservice.helper.HDMTransferServiceHelper");
