export declare type SdkHRHpfsModule = $.kd.sdk.hr.hpfs.SdkHRHpfsModule;
export declare const SdkHRHpfsModule: $.kd.sdk.hr.hpfs.SdkHRHpfsModule_C;
