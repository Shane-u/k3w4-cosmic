export declare type HOMLoginServiceHelper = $.kd.sdk.hr.hom.business.mservice.helper.HOMLoginServiceHelper;
export declare const HOMLoginServiceHelper: $.kd.sdk.hr.hom.business.mservice.helper.HOMLoginServiceHelper_C;
