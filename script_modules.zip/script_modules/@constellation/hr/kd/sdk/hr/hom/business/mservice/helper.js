export const HOMLoginServiceHelper = $.type("kd.sdk.hr.hom.business.mservice.helper.HOMLoginServiceHelper");
