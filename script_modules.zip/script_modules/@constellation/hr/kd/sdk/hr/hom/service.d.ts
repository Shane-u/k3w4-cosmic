export declare type IHOMLoginService = $.kd.sdk.hr.hom.service.IHOMLoginService;
export declare const IHOMLoginService: $.kd.sdk.hr.hom.service.IHOMLoginService;
export declare type IOnbrdInfoService = $.kd.sdk.hr.hom.service.IOnbrdInfoService;
export declare const IOnbrdInfoService: $.kd.sdk.hr.hom.service.IOnbrdInfoService;
