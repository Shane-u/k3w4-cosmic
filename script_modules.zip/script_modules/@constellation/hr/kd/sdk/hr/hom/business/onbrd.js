export const IConfirmOnbrdService = $.type("kd.sdk.hr.hom.business.onbrd.IConfirmOnbrdService");
export const IOnbrdService = $.type("kd.sdk.hr.hom.business.onbrd.IOnbrdService");
export const IPerChgBizParam = $.type("kd.sdk.hr.hom.business.onbrd.IPerChgBizParam");
export const IShareTaskService = $.type("kd.sdk.hr.hom.business.onbrd.IShareTaskService");
