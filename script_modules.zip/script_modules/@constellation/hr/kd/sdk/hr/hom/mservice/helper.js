export const HOMServiceHelper = $.type("kd.sdk.hr.hom.mservice.helper.HOMServiceHelper");
