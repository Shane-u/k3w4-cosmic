export declare type IConfirmOnbrdService = $.kd.sdk.hr.hom.business.onbrd.IConfirmOnbrdService;
export declare const IConfirmOnbrdService: $.kd.sdk.hr.hom.business.onbrd.IConfirmOnbrdService;
export declare type IOnbrdService = $.kd.sdk.hr.hom.business.onbrd.IOnbrdService;
export declare const IOnbrdService: $.kd.sdk.hr.hom.business.onbrd.IOnbrdService;
export declare type IPerChgBizParam = $.kd.sdk.hr.hom.business.onbrd.IPerChgBizParam;
export declare const IPerChgBizParam: $.kd.sdk.hr.hom.business.onbrd.IPerChgBizParam;
export declare type IShareTaskService = $.kd.sdk.hr.hom.business.onbrd.IShareTaskService;
export declare const IShareTaskService: $.kd.sdk.hr.hom.business.onbrd.IShareTaskService;
