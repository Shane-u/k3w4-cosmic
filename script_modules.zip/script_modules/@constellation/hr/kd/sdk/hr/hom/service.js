export const IHOMLoginService = $.type("kd.sdk.hr.hom.service.IHOMLoginService");
export const IOnbrdInfoService = $.type("kd.sdk.hr.hom.service.IOnbrdInfoService");
