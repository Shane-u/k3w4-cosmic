export declare type HOMServiceHelper = $.kd.sdk.hr.hom.mservice.helper.HOMServiceHelper;
export declare const HOMServiceHelper: $.kd.sdk.hr.hom.mservice.helper.HOMServiceHelper_C;
