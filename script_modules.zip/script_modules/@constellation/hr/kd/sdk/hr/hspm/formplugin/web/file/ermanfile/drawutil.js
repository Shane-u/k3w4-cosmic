export const ApControlService = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.ApControlService");
export const ApCreateUtils = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.ApCreateUtils");
export const CustomDrawUtils = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.CustomDrawUtils");
export const DynamicPanelUtils = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.DynamicPanelUtils");
export const FieldContainerViewService = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.FieldContainerViewService");
export const TemplateEditUtils = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.drawutil.TemplateEditUtils");
