export const ErmanFileRepository = $.type("kd.sdk.hr.hspm.business.repository.ErmanFileRepository");
