export declare type InfoclassifyPercreField = $.kd.sdk.hr.hspm.common.entity.InfoclassifyPercreField;
export declare const InfoclassifyPercreField: $.kd.sdk.hr.hspm.common.entity.InfoclassifyPercreField_C;
export declare type PercreField = $.kd.sdk.hr.hspm.common.entity.PercreField;
export declare const PercreField: $.kd.sdk.hr.hspm.common.entity.PercreField_C;
