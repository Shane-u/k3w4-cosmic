export const InfoclassifyPercreField = $.type("kd.sdk.hr.hspm.common.entity.InfoclassifyPercreField");
export const PercreField = $.type("kd.sdk.hr.hspm.common.entity.PercreField");
