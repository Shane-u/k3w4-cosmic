export const FileRelationModel = $.type("kd.sdk.hr.hspm.common.model.FileRelationModel");
