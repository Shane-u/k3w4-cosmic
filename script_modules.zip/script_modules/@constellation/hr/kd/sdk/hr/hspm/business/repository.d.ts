export declare type ErmanFileRepository = $.kd.sdk.hr.hspm.business.repository.ErmanFileRepository;
export declare const ErmanFileRepository: $.kd.sdk.hr.hspm.business.repository.ErmanFileRepository_C;
