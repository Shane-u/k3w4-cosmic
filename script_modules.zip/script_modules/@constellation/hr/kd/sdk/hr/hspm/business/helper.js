export const ApprovalHelper = $.type("kd.sdk.hr.hspm.business.helper.ApprovalHelper");
export const BasedataHelper = $.type("kd.sdk.hr.hspm.business.helper.BasedataHelper");
export const CommonQFilterHelper = $.type("kd.sdk.hr.hspm.business.helper.CommonQFilterHelper");
export const HSPMBusinessDataServiceHelper = $.type("kd.sdk.hr.hspm.business.helper.HSPMBusinessDataServiceHelper");
export const HpfsChgexternalrecordQueueHelper = $.type("kd.sdk.hr.hspm.business.helper.HpfsChgexternalrecordQueueHelper");
export const InfoGroupHelper = $.type("kd.sdk.hr.hspm.business.helper.InfoGroupHelper");
