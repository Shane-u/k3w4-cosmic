export const ChangeDto = $.type("kd.sdk.hr.hspm.common.dto.ChangeDto");
export const DrawFormFieldDto = $.type("kd.sdk.hr.hspm.common.dto.DrawFormFieldDto");
export const HpfsChgexternalrecordQueueDto = $.type("kd.sdk.hr.hspm.common.dto.HpfsChgexternalrecordQueueDto");
export const PereduexpcertDynDto = $.type("kd.sdk.hr.hspm.common.dto.PereduexpcertDynDto");
export const PersonModelDto = $.type("kd.sdk.hr.hspm.common.dto.PersonModelDto");
