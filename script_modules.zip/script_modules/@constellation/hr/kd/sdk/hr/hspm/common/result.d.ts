export declare type HisResponseParse = $.kd.sdk.hr.hspm.common.result.HisResponseParse;
export declare const HisResponseParse: $.kd.sdk.hr.hspm.common.result.HisResponseParse_C;
export declare type HrpiServiceOperateResult = $.kd.sdk.hr.hspm.common.result.HrpiServiceOperateResult;
export declare const HrpiServiceOperateResult: $.kd.sdk.hr.hspm.common.result.HrpiServiceOperateResult_C;
export declare type PerChgSend = $.kd.sdk.hr.hspm.common.result.PerChgSend;
export declare const PerChgSend: $.kd.sdk.hr.hspm.common.result.PerChgSend_C;
