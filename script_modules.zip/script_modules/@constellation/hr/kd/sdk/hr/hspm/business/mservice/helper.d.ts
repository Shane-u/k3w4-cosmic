export declare type HSPMServiceHelper = $.kd.sdk.hr.hspm.business.mservice.helper.HSPMServiceHelper;
export declare const HSPMServiceHelper: $.kd.sdk.hr.hspm.business.mservice.helper.HSPMServiceHelper_C;
