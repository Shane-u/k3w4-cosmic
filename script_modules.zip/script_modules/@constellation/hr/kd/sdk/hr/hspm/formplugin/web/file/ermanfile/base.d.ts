export declare type AbstractCardDrawEdit = $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractCardDrawEdit;
export declare const AbstractCardDrawEdit: $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractCardDrawEdit_C;
export declare type AbstractEntryEntityDrawEdit = $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractEntryEntityDrawEdit;
export declare const AbstractEntryEntityDrawEdit: $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractEntryEntityDrawEdit_C;
export declare type AbstractFormDrawEdit = $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractFormDrawEdit;
export declare const AbstractFormDrawEdit: $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractFormDrawEdit_C;
export declare type CommonSingleFormDrawEdit = $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.CommonSingleFormDrawEdit;
export declare const CommonSingleFormDrawEdit: $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.CommonSingleFormDrawEdit_C;
