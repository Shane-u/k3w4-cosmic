export const AttacheHandlerService = $.type("kd.sdk.hr.hspm.business.service.AttacheHandlerService");
export const ErManFileQfilter = $.type("kd.sdk.hr.hspm.business.service.ErManFileQfilter");
export const MultiViewTemplateService = $.type("kd.sdk.hr.hspm.business.service.MultiViewTemplateService");
export const PageRegConfigService = $.type("kd.sdk.hr.hspm.business.service.PageRegConfigService");
