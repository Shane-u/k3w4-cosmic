export declare type ManagePCFullFormDrawEdit = $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.ext.template.ManagePCFullFormDrawEdit;
export declare const ManagePCFullFormDrawEdit: $.kd.sdk.hr.hspm.formplugin.web.file.ermanfile.ext.template.ManagePCFullFormDrawEdit_C;
