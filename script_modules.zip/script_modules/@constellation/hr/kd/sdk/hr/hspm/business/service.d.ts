export declare type AttacheHandlerService = $.kd.sdk.hr.hspm.business.service.AttacheHandlerService;
export declare const AttacheHandlerService: $.kd.sdk.hr.hspm.business.service.AttacheHandlerService_C;
export declare type ErManFileQfilter = $.kd.sdk.hr.hspm.business.service.ErManFileQfilter;
export declare const ErManFileQfilter: $.kd.sdk.hr.hspm.business.service.ErManFileQfilter_C;
export declare type MultiViewTemplateService = $.kd.sdk.hr.hspm.business.service.MultiViewTemplateService;
export declare const MultiViewTemplateService: $.kd.sdk.hr.hspm.business.service.MultiViewTemplateService_C;
export declare type PageRegConfigService = $.kd.sdk.hr.hspm.business.service.PageRegConfigService;
export declare const PageRegConfigService: $.kd.sdk.hr.hspm.business.service.PageRegConfigService_C;
