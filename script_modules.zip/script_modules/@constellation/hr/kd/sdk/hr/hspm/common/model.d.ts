export declare type FileRelationModel = $.kd.sdk.hr.hspm.common.model.FileRelationModel;
export declare const FileRelationModel: $.kd.sdk.hr.hspm.common.model.FileRelationModel_C;
