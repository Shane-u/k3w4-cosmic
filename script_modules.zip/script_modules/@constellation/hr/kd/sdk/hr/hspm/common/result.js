export const HisResponseParse = $.type("kd.sdk.hr.hspm.common.result.HisResponseParse");
export const HrpiServiceOperateResult = $.type("kd.sdk.hr.hspm.common.result.HrpiServiceOperateResult");
export const PerChgSend = $.type("kd.sdk.hr.hspm.common.result.PerChgSend");
