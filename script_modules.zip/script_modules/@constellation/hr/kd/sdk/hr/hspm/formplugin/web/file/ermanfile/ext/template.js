export const ManagePCFullFormDrawEdit = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.ext.template.ManagePCFullFormDrawEdit");
