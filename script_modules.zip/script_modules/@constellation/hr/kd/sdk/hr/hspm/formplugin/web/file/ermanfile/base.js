export const AbstractCardDrawEdit = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractCardDrawEdit");
export const AbstractEntryEntityDrawEdit = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractEntryEntityDrawEdit");
export const AbstractFormDrawEdit = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.AbstractFormDrawEdit");
export const CommonSingleFormDrawEdit = $.type("kd.sdk.hr.hspm.formplugin.web.file.ermanfile.base.CommonSingleFormDrawEdit");
