export const HSPMServiceHelper = $.type("kd.sdk.hr.hspm.business.mservice.helper.HSPMServiceHelper");
