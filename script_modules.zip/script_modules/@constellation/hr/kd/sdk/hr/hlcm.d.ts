export declare type SdkHRHlcmModule = $.kd.sdk.hr.hlcm.SdkHRHlcmModule;
export declare const SdkHRHlcmModule: $.kd.sdk.hr.hlcm.SdkHRHlcmModule_C;
