export declare type SdkHRHdmModule = $.kd.sdk.hr.hdm.SdkHRHdmModule;
export declare const SdkHRHdmModule: $.kd.sdk.hr.hdm.SdkHRHdmModule_C;
