export const SdkHRHlcmModule = $.type("kd.sdk.hr.hlcm.business.SdkHRHlcmModule");
