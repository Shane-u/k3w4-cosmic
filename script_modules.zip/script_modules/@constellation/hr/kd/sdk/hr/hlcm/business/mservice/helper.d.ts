export declare type ContractServiceHelper = $.kd.sdk.hr.hlcm.business.mservice.helper.ContractServiceHelper;
export declare const ContractServiceHelper: $.kd.sdk.hr.hlcm.business.mservice.helper.ContractServiceHelper_C;
