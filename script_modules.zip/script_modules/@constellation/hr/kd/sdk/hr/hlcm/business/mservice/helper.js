export const ContractServiceHelper = $.type("kd.sdk.hr.hlcm.business.mservice.helper.ContractServiceHelper");
