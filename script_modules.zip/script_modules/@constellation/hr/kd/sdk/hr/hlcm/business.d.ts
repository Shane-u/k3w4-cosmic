export declare type SdkHRHlcmModule = $.kd.sdk.hr.hlcm.business.SdkHRHlcmModule;
export declare const SdkHRHlcmModule: $.kd.sdk.hr.hlcm.business.SdkHRHlcmModule_C;
