export const HTMQuitBillServiceHelper = $.type("kd.sdk.hr.htm.business.mservice.helper.HTMQuitBillServiceHelper");
