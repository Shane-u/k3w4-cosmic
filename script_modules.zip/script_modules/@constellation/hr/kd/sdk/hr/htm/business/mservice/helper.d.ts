export declare type HTMQuitBillServiceHelper = $.kd.sdk.hr.htm.business.mservice.helper.HTMQuitBillServiceHelper;
export declare const HTMQuitBillServiceHelper: $.kd.sdk.hr.htm.business.mservice.helper.HTMQuitBillServiceHelper_C;
