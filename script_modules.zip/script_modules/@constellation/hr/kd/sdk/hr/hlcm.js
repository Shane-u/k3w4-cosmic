export const SdkHRHlcmModule = $.type("kd.sdk.hr.hlcm.SdkHRHlcmModule");
