export const ChgFlowTypeEnum = $.type("kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgFlowTypeEnum");
export const ChgLogEntryStatusEnum = $.type("kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgLogEntryStatusEnum");
export const ChgModeEnum = $.type("kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgModeEnum");
