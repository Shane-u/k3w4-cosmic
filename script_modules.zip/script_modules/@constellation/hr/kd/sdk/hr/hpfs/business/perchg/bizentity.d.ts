export declare type PerChgAttachment = $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgAttachment;
export declare const PerChgAttachment: $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgAttachment_C;
export declare type PerChgBizInfo = $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizInfo;
export declare const PerChgBizInfo: $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizInfo_C;
export declare type PerChgBizResult = $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizResult;
export declare const PerChgBizResult: $.kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizResult_C;
