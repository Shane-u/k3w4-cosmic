export const DynFilePagePlugin = $.type("kd.sdk.hr.hpfs.formplugin.file.DynFilePagePlugin");
export const MultiViewTemplatePlugin = $.type("kd.sdk.hr.hpfs.formplugin.file.MultiViewTemplatePlugin");
