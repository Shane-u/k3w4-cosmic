export const ChgExternalDataEntryDto = $.type("kd.sdk.hr.hpfs.business.perchg.executor.model.ChgExternalDataEntryDto");
export const ChgLogEntryDto = $.type("kd.sdk.hr.hpfs.business.perchg.executor.model.ChgLogEntryDto");
export const ChgRecordEntryDto = $.type("kd.sdk.hr.hpfs.business.perchg.executor.model.ChgRecordEntryDto");
