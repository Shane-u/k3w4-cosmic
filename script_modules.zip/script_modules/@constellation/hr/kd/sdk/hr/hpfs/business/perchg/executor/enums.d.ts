export declare type ChgFlowTypeEnum = $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgFlowTypeEnum;
export declare const ChgFlowTypeEnum: typeof $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgFlowTypeEnum;
export declare type ChgLogEntryStatusEnum = $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgLogEntryStatusEnum;
export declare const ChgLogEntryStatusEnum: typeof $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgLogEntryStatusEnum;
export declare type ChgModeEnum = $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgModeEnum;
export declare const ChgModeEnum: typeof $.kd.sdk.hr.hpfs.business.perchg.executor.enums.ChgModeEnum;
