export declare type DynFilePagePlugin = $.kd.sdk.hr.hpfs.formplugin.file.DynFilePagePlugin;
export declare const DynFilePagePlugin: $.kd.sdk.hr.hpfs.formplugin.file.DynFilePagePlugin_C;
export declare type MultiViewTemplatePlugin = $.kd.sdk.hr.hpfs.formplugin.file.MultiViewTemplatePlugin;
export declare const MultiViewTemplatePlugin: $.kd.sdk.hr.hpfs.formplugin.file.MultiViewTemplatePlugin_C;
