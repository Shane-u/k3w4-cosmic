export declare type HPFSPersonChgServiceHelper = $.kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonChgServiceHelper;
export declare const HPFSPersonChgServiceHelper: $.kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonChgServiceHelper_C;
export declare type HPFSPersonFlowServiceHelper = $.kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonFlowServiceHelper;
export declare const HPFSPersonFlowServiceHelper: $.kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonFlowServiceHelper_C;
