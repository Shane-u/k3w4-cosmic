export const MultiViewTempService = $.type("kd.sdk.hr.hpfs.business.file.MultiViewTempService");
