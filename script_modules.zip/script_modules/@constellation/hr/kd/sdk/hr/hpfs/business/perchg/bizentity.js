export const PerChgAttachment = $.type("kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgAttachment");
export const PerChgBizInfo = $.type("kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizInfo");
export const PerChgBizResult = $.type("kd.sdk.hr.hpfs.business.perchg.bizentity.PerChgBizResult");
