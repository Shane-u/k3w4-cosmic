export declare type ChgExternalDataEntryDto = $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgExternalDataEntryDto;
export declare const ChgExternalDataEntryDto: $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgExternalDataEntryDto_C;
export declare type ChgLogEntryDto = $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgLogEntryDto;
export declare const ChgLogEntryDto: $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgLogEntryDto_C;
export declare type ChgRecordEntryDto = $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgRecordEntryDto;
export declare const ChgRecordEntryDto: $.kd.sdk.hr.hpfs.business.perchg.executor.model.ChgRecordEntryDto_C;
