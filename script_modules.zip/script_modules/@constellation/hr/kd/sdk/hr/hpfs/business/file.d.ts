export declare type MultiViewTempService = $.kd.sdk.hr.hpfs.business.file.MultiViewTempService;
export declare const MultiViewTempService: $.kd.sdk.hr.hpfs.business.file.MultiViewTempService_C;
