export const HPFSPersonChgServiceHelper = $.type("kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonChgServiceHelper");
export const HPFSPersonFlowServiceHelper = $.type("kd.sdk.hr.hpfs.business.mservice.helper.HPFSPersonFlowServiceHelper");
