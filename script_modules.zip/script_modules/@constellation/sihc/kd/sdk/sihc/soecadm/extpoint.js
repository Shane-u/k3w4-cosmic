export const AbstractActivityBillCommonService = $.type("kd.sdk.sihc.soecadm.extpoint.AbstractActivityBillCommonService");
