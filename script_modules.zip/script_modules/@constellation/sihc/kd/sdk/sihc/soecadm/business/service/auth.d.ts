export declare type AuthOrgService = $.kd.sdk.sihc.soecadm.business.service.auth.AuthOrgService;
export declare const AuthOrgService: $.kd.sdk.sihc.soecadm.business.service.auth.AuthOrgService_C;
