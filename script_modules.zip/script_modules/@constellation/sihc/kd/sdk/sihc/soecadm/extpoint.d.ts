export declare type AbstractActivityBillCommonService = $.kd.sdk.sihc.soecadm.extpoint.AbstractActivityBillCommonService;
export declare const AbstractActivityBillCommonService: $.kd.sdk.sihc.soecadm.extpoint.AbstractActivityBillCommonService_C;
