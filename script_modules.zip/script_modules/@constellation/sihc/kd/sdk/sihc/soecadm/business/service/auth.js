export const AuthOrgService = $.type("kd.sdk.sihc.soecadm.business.service.auth.AuthOrgService");
