export declare type ActivityGroupInsCommonService = $.kd.sdk.sihc.soecadm.business.service.activity.ActivityGroupInsCommonService;
export declare const ActivityGroupInsCommonService: $.kd.sdk.sihc.soecadm.business.service.activity.ActivityGroupInsCommonService_C;
