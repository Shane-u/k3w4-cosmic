export const ActivityGroupInsCommonService = $.type("kd.sdk.sihc.soecadm.business.service.activity.ActivityGroupInsCommonService");
