export const CadreFileReportExtRelationFilterDTO = $.type("kd.sdk.sihc.soebs.business.service.cadrefile.CadreFileReportExtRelationFilterDTO");
export const CadreSnapReportExtHisQueryDateDTO = $.type("kd.sdk.sihc.soebs.business.service.cadrefile.CadreSnapReportExtHisQueryDateDTO");
