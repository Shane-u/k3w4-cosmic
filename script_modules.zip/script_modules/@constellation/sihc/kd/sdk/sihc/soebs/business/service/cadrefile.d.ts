export declare type CadreFileReportExtRelationFilterDTO = $.kd.sdk.sihc.soebs.business.service.cadrefile.CadreFileReportExtRelationFilterDTO;
export declare const CadreFileReportExtRelationFilterDTO: $.kd.sdk.sihc.soebs.business.service.cadrefile.CadreFileReportExtRelationFilterDTO_C;
export declare type CadreSnapReportExtHisQueryDateDTO = $.kd.sdk.sihc.soebs.business.service.cadrefile.CadreSnapReportExtHisQueryDateDTO;
export declare const CadreSnapReportExtHisQueryDateDTO: $.kd.sdk.sihc.soebs.business.service.cadrefile.CadreSnapReportExtHisQueryDateDTO_C;
