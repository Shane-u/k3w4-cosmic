export const SdkSihcSoecadmModule = $.type("kd.sdk.sihc.soecadm.SdkSihcSoecadmModule");
