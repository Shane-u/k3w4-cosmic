export declare type SdkSihcSoecadmModule = $.kd.sdk.sihc.soecadm.SdkSihcSoecadmModule;
export declare const SdkSihcSoecadmModule: $.kd.sdk.sihc.soecadm.SdkSihcSoecadmModule_C;
