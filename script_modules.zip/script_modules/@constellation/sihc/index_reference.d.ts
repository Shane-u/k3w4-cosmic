/// <reference types="./kd/sdk/sihc/soecadm/business/service/auth" />
/// <reference types="./kd/sdk/sihc/soecadm/extpoint" />
/// <reference types="./kd/sdk/sihc/soecadm/business/service/activity" />
/// <reference types="./kd/sdk/sihc/soebs/business/service/cadrefile" />
/// <reference types="./kd/sdk/sihc/soecadm" />
/// <reference types="./index" />
