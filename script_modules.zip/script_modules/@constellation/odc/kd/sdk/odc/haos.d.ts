/// <reference types="../../../index" />
export declare type SdkOdcHaosModule = $.kd.sdk.odc.haos.SdkOdcHaosModule;
export declare const SdkOdcHaosModule: $.kd.sdk.odc.haos.SdkOdcHaosModule_C;
