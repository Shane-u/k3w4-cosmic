/// <reference types="../../../index" />
export declare type SdkOdcHbpmModule = $.kd.sdk.odc.hbpm.SdkOdcHbpmModule;
export declare const SdkOdcHbpmModule: $.kd.sdk.odc.hbpm.SdkOdcHbpmModule_C;
