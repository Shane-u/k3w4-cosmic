export const SdkOdcHaosModule = $.type("kd.sdk.odc.haos.SdkOdcHaosModule");
