/// <reference types="../../../../index" />
export declare type IPositionSDKService = $.kd.sdk.odc.hbpm.service.IPositionSDKService;
export declare const IPositionSDKService: $.kd.sdk.odc.hbpm.service.IPositionSDKService;
