export const IPositionSDKService = $.type("kd.sdk.odc.hbpm.service.IPositionSDKService");
