export const SdkOdcHbpmModule = $.type("kd.sdk.odc.hbpm.SdkOdcHbpmModule");
