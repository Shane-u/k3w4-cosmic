export const IAdminOrgSDKService = $.type("kd.sdk.odc.haos.service.IAdminOrgSDKService");
