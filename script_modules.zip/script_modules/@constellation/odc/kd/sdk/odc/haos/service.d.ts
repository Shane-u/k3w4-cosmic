/// <reference types="../../../../index" />
export declare type IAdminOrgSDKService = $.kd.sdk.odc.haos.service.IAdminOrgSDKService;
export declare const IAdminOrgSDKService: $.kd.sdk.odc.haos.service.IAdminOrgSDKService;
