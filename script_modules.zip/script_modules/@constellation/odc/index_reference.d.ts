/// <reference types="./kd/sdk/odc/hbpm" />
/// <reference types="./kd/sdk/odc/haos/service" />
/// <reference types="./kd/sdk/odc/hbpm/service" />
/// <reference types="./kd/sdk/odc/haos" />
/// <reference types="./index" />
