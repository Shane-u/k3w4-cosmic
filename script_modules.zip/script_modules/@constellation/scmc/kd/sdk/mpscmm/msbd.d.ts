export declare type SdkMsbdModule = $.kd.sdk.mpscmm.msbd.SdkMsbdModule;
export declare const SdkMsbdModule: $.kd.sdk.mpscmm.msbd.SdkMsbdModule_C;
