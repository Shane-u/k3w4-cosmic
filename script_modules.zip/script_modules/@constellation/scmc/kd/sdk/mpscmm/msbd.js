export const SdkMsbdModule = $.type("kd.sdk.mpscmm.msbd.SdkMsbdModule");
