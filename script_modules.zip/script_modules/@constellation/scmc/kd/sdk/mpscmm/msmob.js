export const SdkMsmobModule = $.type("kd.sdk.mpscmm.msmob.SdkMsmobModule");
