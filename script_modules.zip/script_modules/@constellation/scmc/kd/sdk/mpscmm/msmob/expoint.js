export const IMobBotpResultHandlerPlugin = $.type("kd.sdk.mpscmm.msmob.expoint.IMobBotpResultHandlerPlugin");
export const IMobHomePageCustomDataPlugin = $.type("kd.sdk.mpscmm.msmob.expoint.IMobHomePageCustomDataPlugin");
export const IMobOpenApiUrlMapping = $.type("kd.sdk.mpscmm.msmob.expoint.IMobOpenApiUrlMapping");
export const IMobOperationDataTransferPlugin = $.type("kd.sdk.mpscmm.msmob.expoint.IMobOperationDataTransferPlugin");
export const MsmobExpandCaseCodes = $.type("kd.sdk.mpscmm.msmob.expoint.MsmobExpandCaseCodes");
