export const SdkMsconModule = $.type("kd.sdk.mpscmm.mscon.SdkMsconModule");
