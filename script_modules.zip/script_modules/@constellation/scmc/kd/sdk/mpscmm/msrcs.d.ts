export declare type SdkMsrcsModule = $.kd.sdk.mpscmm.msrcs.SdkMsrcsModule;
export declare const SdkMsrcsModule: $.kd.sdk.mpscmm.msrcs.SdkMsrcsModule_C;
