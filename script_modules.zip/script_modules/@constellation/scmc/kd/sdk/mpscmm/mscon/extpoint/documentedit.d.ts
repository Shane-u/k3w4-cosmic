export declare type IDocumentPlugin = $.kd.sdk.mpscmm.mscon.extpoint.documentedit.IDocumentPlugin;
export declare const IDocumentPlugin: $.kd.sdk.mpscmm.mscon.extpoint.documentedit.IDocumentPlugin;
