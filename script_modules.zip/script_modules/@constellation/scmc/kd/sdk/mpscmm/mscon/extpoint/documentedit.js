export const IDocumentPlugin = $.type("kd.sdk.mpscmm.mscon.extpoint.documentedit.IDocumentPlugin");
