export declare type IRebatePlugin = $.kd.sdk.mpscmm.msrcs.extpoint.IRebatePlugin;
export declare const IRebatePlugin: $.kd.sdk.mpscmm.msrcs.extpoint.IRebatePlugin;
