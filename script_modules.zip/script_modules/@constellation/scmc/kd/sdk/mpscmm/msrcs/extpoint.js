export const IRebatePlugin = $.type("kd.sdk.mpscmm.msrcs.extpoint.IRebatePlugin");
