export declare type IWorkBenchPlugin = $.kd.sdk.mpscmm.msbd.expoint.workbench.IWorkBenchPlugin;
export declare const IWorkBenchPlugin: $.kd.sdk.mpscmm.msbd.expoint.workbench.IWorkBenchPlugin;
