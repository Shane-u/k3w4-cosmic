export const IDataCtrlCasePlugin = $.type("kd.sdk.mpscmm.msbd.expoint.datacontrol.IDataCtrlCasePlugin");
