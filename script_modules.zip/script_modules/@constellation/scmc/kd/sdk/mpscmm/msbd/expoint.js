export const MsbdExpandCaseCodes = $.type("kd.sdk.mpscmm.msbd.expoint.MsbdExpandCaseCodes");
