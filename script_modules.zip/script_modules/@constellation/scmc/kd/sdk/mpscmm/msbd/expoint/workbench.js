export const IWorkBenchPlugin = $.type("kd.sdk.mpscmm.msbd.expoint.workbench.IWorkBenchPlugin");
