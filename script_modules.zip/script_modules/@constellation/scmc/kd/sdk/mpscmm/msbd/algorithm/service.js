export const AlgorithmService = $.type("kd.sdk.mpscmm.msbd.algorithm.service.AlgorithmService");
