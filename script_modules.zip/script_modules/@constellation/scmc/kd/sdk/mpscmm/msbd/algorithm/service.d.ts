export declare type AlgorithmService = $.kd.sdk.mpscmm.msbd.algorithm.service.AlgorithmService;
export declare const AlgorithmService: $.kd.sdk.mpscmm.msbd.algorithm.service.AlgorithmService;
