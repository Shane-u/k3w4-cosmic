export declare type MsbdExpandCaseCodes = $.kd.sdk.mpscmm.msbd.expoint.MsbdExpandCaseCodes;
export declare const MsbdExpandCaseCodes: $.kd.sdk.mpscmm.msbd.expoint.MsbdExpandCaseCodes_C;
