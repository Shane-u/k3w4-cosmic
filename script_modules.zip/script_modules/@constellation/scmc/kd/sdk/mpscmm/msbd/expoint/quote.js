export const IQuoteCasePlugin = $.type("kd.sdk.mpscmm.msbd.expoint.quote.IQuoteCasePlugin");
export const QuoteDoParam = $.type("kd.sdk.mpscmm.msbd.expoint.quote.QuoteDoParam");
export const QuoteFilterParam = $.type("kd.sdk.mpscmm.msbd.expoint.quote.QuoteFilterParam");
