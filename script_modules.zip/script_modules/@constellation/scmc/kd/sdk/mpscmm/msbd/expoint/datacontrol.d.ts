export declare type IDataCtrlCasePlugin = $.kd.sdk.mpscmm.msbd.expoint.datacontrol.IDataCtrlCasePlugin;
export declare const IDataCtrlCasePlugin: $.kd.sdk.mpscmm.msbd.expoint.datacontrol.IDataCtrlCasePlugin;
