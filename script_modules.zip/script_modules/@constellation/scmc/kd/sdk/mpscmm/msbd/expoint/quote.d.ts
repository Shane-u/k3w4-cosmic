export declare type IQuoteCasePlugin = $.kd.sdk.mpscmm.msbd.expoint.quote.IQuoteCasePlugin;
export declare const IQuoteCasePlugin: $.kd.sdk.mpscmm.msbd.expoint.quote.IQuoteCasePlugin;
export declare type QuoteDoParam = $.kd.sdk.mpscmm.msbd.expoint.quote.QuoteDoParam;
export declare const QuoteDoParam: $.kd.sdk.mpscmm.msbd.expoint.quote.QuoteDoParam_C;
export declare type QuoteFilterParam = $.kd.sdk.mpscmm.msbd.expoint.quote.QuoteFilterParam;
export declare const QuoteFilterParam: $.kd.sdk.mpscmm.msbd.expoint.quote.QuoteFilterParam_C;
