export const SdkMsrcsModule = $.type("kd.sdk.mpscmm.msrcs.SdkMsrcsModule");
