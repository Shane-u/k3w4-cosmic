export declare type SdkMsconModule = $.kd.sdk.mpscmm.mscon.SdkMsconModule;
export declare const SdkMsconModule: $.kd.sdk.mpscmm.mscon.SdkMsconModule_C;
