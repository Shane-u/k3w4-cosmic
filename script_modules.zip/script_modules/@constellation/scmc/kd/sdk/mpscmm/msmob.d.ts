export declare type SdkMsmobModule = $.kd.sdk.mpscmm.msmob.SdkMsmobModule;
export declare const SdkMsmobModule: $.kd.sdk.mpscmm.msmob.SdkMsmobModule_C;
