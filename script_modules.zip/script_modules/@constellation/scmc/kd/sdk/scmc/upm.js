export const SdkScmcUpmModule = $.type("kd.sdk.scmc.upm.SdkScmcUpmModule");
