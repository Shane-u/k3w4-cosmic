export declare type SdkScmcConmModule = $.kd.sdk.scmc.conm.SdkScmcConmModule;
export declare const SdkScmcConmModule: $.kd.sdk.scmc.conm.SdkScmcConmModule_C;
