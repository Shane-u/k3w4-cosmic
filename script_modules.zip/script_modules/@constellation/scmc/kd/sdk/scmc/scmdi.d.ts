export declare type SdkScmcDiModule = $.kd.sdk.scmc.scmdi.SdkScmcDiModule;
export declare const SdkScmcDiModule: $.kd.sdk.scmc.scmdi.SdkScmcDiModule_C;
