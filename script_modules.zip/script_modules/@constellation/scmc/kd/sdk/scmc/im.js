export const SdkScmcImModule = $.type("kd.sdk.scmc.im.SdkScmcImModule");
