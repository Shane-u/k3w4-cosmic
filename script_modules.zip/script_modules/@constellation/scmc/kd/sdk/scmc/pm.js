export const SdkScmcPmModule = $.type("kd.sdk.scmc.pm.SdkScmcPmModule");
