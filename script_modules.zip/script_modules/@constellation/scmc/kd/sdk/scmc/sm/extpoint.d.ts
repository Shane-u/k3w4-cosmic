export declare type IAmountCalculateCasePlugin = $.kd.sdk.scmc.sm.extpoint.IAmountCalculateCasePlugin;
export declare const IAmountCalculateCasePlugin: $.kd.sdk.scmc.sm.extpoint.IAmountCalculateCasePlugin;
export declare type ICleanFieldsCasePlugin = $.kd.sdk.scmc.sm.extpoint.ICleanFieldsCasePlugin;
export declare const ICleanFieldsCasePlugin: $.kd.sdk.scmc.sm.extpoint.ICleanFieldsCasePlugin;
export declare type IXSalOrderCasePlugin = $.kd.sdk.scmc.sm.extpoint.IXSalOrderCasePlugin;
export declare const IXSalOrderCasePlugin: $.kd.sdk.scmc.sm.extpoint.IXSalOrderCasePlugin;
export declare type SmExpandCaseCodes = $.kd.sdk.scmc.sm.extpoint.SmExpandCaseCodes;
export declare const SmExpandCaseCodes: $.kd.sdk.scmc.sm.extpoint.SmExpandCaseCodes_C;
