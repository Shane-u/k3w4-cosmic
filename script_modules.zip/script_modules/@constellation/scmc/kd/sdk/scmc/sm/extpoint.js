export const IAmountCalculateCasePlugin = $.type("kd.sdk.scmc.sm.extpoint.IAmountCalculateCasePlugin");
export const ICleanFieldsCasePlugin = $.type("kd.sdk.scmc.sm.extpoint.ICleanFieldsCasePlugin");
export const IXSalOrderCasePlugin = $.type("kd.sdk.scmc.sm.extpoint.IXSalOrderCasePlugin");
export const SmExpandCaseCodes = $.type("kd.sdk.scmc.sm.extpoint.SmExpandCaseCodes");
