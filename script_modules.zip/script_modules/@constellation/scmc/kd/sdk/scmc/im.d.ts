export declare type SdkScmcImModule = $.kd.sdk.scmc.im.SdkScmcImModule;
export declare const SdkScmcImModule: $.kd.sdk.scmc.im.SdkScmcImModule_C;
