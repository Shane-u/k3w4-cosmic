export declare type SdkScmcPmModule = $.kd.sdk.scmc.pm.SdkScmcPmModule;
export declare const SdkScmcPmModule: $.kd.sdk.scmc.pm.SdkScmcPmModule_C;
