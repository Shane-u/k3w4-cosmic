export const IInvBatchFillExpand = $.type("kd.sdk.scmc.im.extpoint.IInvBatchFillExpand");
export const IInvCountSchemeAuditExpand = $.type("kd.sdk.scmc.im.extpoint.IInvCountSchemeAuditExpand");
export const IInvEntrustExpand = $.type("kd.sdk.scmc.im.extpoint.IInvEntrustExpand");
export const IInvMatchruleoutExpand = $.type("kd.sdk.scmc.im.extpoint.IInvMatchruleoutExpand");
export const IInvQueryExpand = $.type("kd.sdk.scmc.im.extpoint.IInvQueryExpand");
export const ImExpandCaseCodes = $.type("kd.sdk.scmc.im.extpoint.ImExpandCaseCodes");
