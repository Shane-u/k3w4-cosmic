export const LotnumService = $.type("kd.sdk.scmc.im.service.LotnumService");
export const MatchingRuleOutService = $.type("kd.sdk.scmc.im.service.MatchingRuleOutService");
