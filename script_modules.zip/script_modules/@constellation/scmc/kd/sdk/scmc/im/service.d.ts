export declare type LotnumService = $.kd.sdk.scmc.im.service.LotnumService;
export declare const LotnumService: $.kd.sdk.scmc.im.service.LotnumService;
export declare type MatchingRuleOutService = $.kd.sdk.scmc.im.service.MatchingRuleOutService;
export declare const MatchingRuleOutService: $.kd.sdk.scmc.im.service.MatchingRuleOutService;
