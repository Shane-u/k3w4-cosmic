export declare type SdkMobImModule = $.kd.sdk.scmc.mobim.SdkMobImModule;
export declare const SdkMobImModule: $.kd.sdk.scmc.mobim.SdkMobImModule_C;
