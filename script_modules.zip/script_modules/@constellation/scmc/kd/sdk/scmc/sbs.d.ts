export declare type SdkScmcSbsModule = $.kd.sdk.scmc.sbs.SdkScmcSbsModule;
export declare const SdkScmcSbsModule: $.kd.sdk.scmc.sbs.SdkScmcSbsModule_C;
