export declare type ISbsSelectSNExpand = $.kd.sdk.scmc.sbs.extpoint.ISbsSelectSNExpand;
export declare const ISbsSelectSNExpand: $.kd.sdk.scmc.sbs.extpoint.ISbsSelectSNExpand;
export declare type SbsExpandCaseCodes = $.kd.sdk.scmc.sbs.extpoint.SbsExpandCaseCodes;
export declare const SbsExpandCaseCodes: $.kd.sdk.scmc.sbs.extpoint.SbsExpandCaseCodes_C;
