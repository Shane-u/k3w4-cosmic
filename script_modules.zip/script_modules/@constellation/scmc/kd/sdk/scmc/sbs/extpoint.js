export const ISbsSelectSNExpand = $.type("kd.sdk.scmc.sbs.extpoint.ISbsSelectSNExpand");
export const SbsExpandCaseCodes = $.type("kd.sdk.scmc.sbs.extpoint.SbsExpandCaseCodes");
