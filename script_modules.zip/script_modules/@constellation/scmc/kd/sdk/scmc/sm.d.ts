export declare type SdkScmcSmModule = $.kd.sdk.scmc.sm.SdkScmcSmModule;
export declare const SdkScmcSmModule: $.kd.sdk.scmc.sm.SdkScmcSmModule_C;
