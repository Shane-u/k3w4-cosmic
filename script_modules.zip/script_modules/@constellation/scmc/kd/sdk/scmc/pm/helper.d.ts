export declare type PmCommonHelper = $.kd.sdk.scmc.pm.helper.PmCommonHelper;
export declare const PmCommonHelper: $.kd.sdk.scmc.pm.helper.PmCommonHelper_C;
export declare type PurApplyHelper = $.kd.sdk.scmc.pm.helper.PurApplyHelper;
export declare const PurApplyHelper: $.kd.sdk.scmc.pm.helper.PurApplyHelper_C;
export declare type PurOrderHelper = $.kd.sdk.scmc.pm.helper.PurOrderHelper;
export declare const PurOrderHelper: $.kd.sdk.scmc.pm.helper.PurOrderHelper_C;
