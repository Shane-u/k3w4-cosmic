export const IForecastPlanCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IForecastPlanCasePlugin");
export const IPurBatChangeCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IPurBatChangeCasePlugin");
export const IPurQuotaCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IPurQuotaCasePlugin");
export const IVMISettleCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IVMISettleCasePlugin");
export const IXPurApplyCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IXPurApplyCasePlugin");
export const IXPurOrderCasePlugin = $.type("kd.sdk.scmc.pm.extpoint.IXPurOrderCasePlugin");
export const PmExpandCaseCodes = $.type("kd.sdk.scmc.pm.extpoint.PmExpandCaseCodes");
