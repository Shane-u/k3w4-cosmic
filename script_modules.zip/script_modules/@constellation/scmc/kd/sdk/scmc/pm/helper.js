export const PmCommonHelper = $.type("kd.sdk.scmc.pm.helper.PmCommonHelper");
export const PurApplyHelper = $.type("kd.sdk.scmc.pm.helper.PurApplyHelper");
export const PurOrderHelper = $.type("kd.sdk.scmc.pm.helper.PurOrderHelper");
