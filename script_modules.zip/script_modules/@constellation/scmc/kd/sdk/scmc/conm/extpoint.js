export const IWebOfficePlugin = $.type("kd.sdk.scmc.conm.extpoint.IWebOfficePlugin");
export const IXContractPlugin = $.type("kd.sdk.scmc.conm.extpoint.IXContractPlugin");
