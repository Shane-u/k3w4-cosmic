export declare type IWebOfficePlugin = $.kd.sdk.scmc.conm.extpoint.IWebOfficePlugin;
export declare const IWebOfficePlugin: $.kd.sdk.scmc.conm.extpoint.IWebOfficePlugin;
export declare type IXContractPlugin = $.kd.sdk.scmc.conm.extpoint.IXContractPlugin;
export declare const IXContractPlugin: $.kd.sdk.scmc.conm.extpoint.IXContractPlugin;
