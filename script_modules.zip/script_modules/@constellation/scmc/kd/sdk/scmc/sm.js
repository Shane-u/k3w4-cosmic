export const SdkScmcSmModule = $.type("kd.sdk.scmc.sm.SdkScmcSmModule");
