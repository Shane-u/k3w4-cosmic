export declare type UpmExpandCaseCodes = $.kd.sdk.scmc.upm.extpoint.UpmExpandCaseCodes;
export declare const UpmExpandCaseCodes: $.kd.sdk.scmc.upm.extpoint.UpmExpandCaseCodes_C;
