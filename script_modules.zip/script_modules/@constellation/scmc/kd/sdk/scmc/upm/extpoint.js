export const UpmExpandCaseCodes = $.type("kd.sdk.scmc.upm.extpoint.UpmExpandCaseCodes");
