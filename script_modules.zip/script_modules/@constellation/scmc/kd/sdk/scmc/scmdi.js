export const SdkScmcDiModule = $.type("kd.sdk.scmc.scmdi.SdkScmcDiModule");
