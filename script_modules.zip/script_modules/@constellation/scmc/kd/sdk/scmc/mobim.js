export const SdkMobImModule = $.type("kd.sdk.scmc.mobim.SdkMobImModule");
