export const SdkScmcSbsModule = $.type("kd.sdk.scmc.sbs.SdkScmcSbsModule");
