export declare type SdkScmcUpmModule = $.kd.sdk.scmc.upm.SdkScmcUpmModule;
export declare const SdkScmcUpmModule: $.kd.sdk.scmc.upm.SdkScmcUpmModule_C;
