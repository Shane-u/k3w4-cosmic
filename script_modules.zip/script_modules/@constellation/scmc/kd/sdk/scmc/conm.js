export const SdkScmcConmModule = $.type("kd.sdk.scmc.conm.SdkScmcConmModule");
