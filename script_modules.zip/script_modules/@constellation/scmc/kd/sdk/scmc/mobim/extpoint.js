export const IInvQueryExpand = $.type("kd.sdk.scmc.mobim.extpoint.IInvQueryExpand");
export const MobImExpandCaseCodes = $.type("kd.sdk.scmc.mobim.extpoint.MobImExpandCaseCodes");
