export declare type IInvQueryExpand = $.kd.sdk.scmc.mobim.extpoint.IInvQueryExpand;
export declare const IInvQueryExpand: $.kd.sdk.scmc.mobim.extpoint.IInvQueryExpand;
export declare type MobImExpandCaseCodes = $.kd.sdk.scmc.mobim.extpoint.MobImExpandCaseCodes;
export declare const MobImExpandCaseCodes: $.kd.sdk.scmc.mobim.extpoint.MobImExpandCaseCodes_C;
