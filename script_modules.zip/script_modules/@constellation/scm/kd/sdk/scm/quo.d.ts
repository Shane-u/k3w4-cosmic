/// <reference types="../../../index" />
export declare type SdkScmQuoModule = $.kd.sdk.scm.quo.SdkScmQuoModule;
export declare const SdkScmQuoModule: $.kd.sdk.scm.quo.SdkScmQuoModule_C;
