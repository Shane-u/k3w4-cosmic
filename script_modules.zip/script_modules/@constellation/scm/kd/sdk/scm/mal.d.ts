/// <reference types="../../../index" />
export declare type SdkScmMalModule = $.kd.sdk.scm.mal.SdkScmMalModule;
export declare const SdkScmMalModule: $.kd.sdk.scm.mal.SdkScmMalModule_C;
