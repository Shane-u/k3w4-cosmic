export const IBatchStockSupport = $.type("kd.sdk.scm.pur.extpoint.IBatchStockSupport");
export const ICreateAPBillSupport = $.type("kd.sdk.scm.pur.extpoint.ICreateAPBillSupport");
export const ICreateOrderSupport = $.type("kd.sdk.scm.pur.extpoint.ICreateOrderSupport");
export const IPurHandCheckSupport = $.type("kd.sdk.scm.pur.extpoint.IPurHandCheckSupport");
export const IPurOrderChangeSupport = $.type("kd.sdk.scm.pur.extpoint.IPurOrderChangeSupport");
