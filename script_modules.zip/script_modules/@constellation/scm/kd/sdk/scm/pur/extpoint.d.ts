/// <reference types="../../../../index" />
export declare type IBatchStockSupport = $.kd.sdk.scm.pur.extpoint.IBatchStockSupport;
export declare const IBatchStockSupport: $.kd.sdk.scm.pur.extpoint.IBatchStockSupport;
export declare type ICreateAPBillSupport = $.kd.sdk.scm.pur.extpoint.ICreateAPBillSupport;
export declare const ICreateAPBillSupport: $.kd.sdk.scm.pur.extpoint.ICreateAPBillSupport;
export declare type ICreateOrderSupport = $.kd.sdk.scm.pur.extpoint.ICreateOrderSupport;
export declare const ICreateOrderSupport: $.kd.sdk.scm.pur.extpoint.ICreateOrderSupport;
export declare type IPurHandCheckSupport = $.kd.sdk.scm.pur.extpoint.IPurHandCheckSupport;
export declare const IPurHandCheckSupport: $.kd.sdk.scm.pur.extpoint.IPurHandCheckSupport;
export declare type IPurOrderChangeSupport = $.kd.sdk.scm.pur.extpoint.IPurOrderChangeSupport;
export declare const IPurOrderChangeSupport: $.kd.sdk.scm.pur.extpoint.IPurOrderChangeSupport;
