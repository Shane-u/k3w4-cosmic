export const SdkScmPsscModule = $.type("kd.sdk.scm.pssc.SdkScmPsscModule");
