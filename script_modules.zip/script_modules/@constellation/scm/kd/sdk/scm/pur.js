export const SdkScmPurModule = $.type("kd.sdk.scm.pur.SdkScmPurModule");
