export const SdkScmPdsModule = $.type("kd.sdk.scm.pds.SdkScmPdsModule");
