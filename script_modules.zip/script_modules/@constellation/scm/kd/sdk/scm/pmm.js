export const SdkScmPmmModule = $.type("kd.sdk.scm.pmm.SdkScmPmmModule");
