/// <reference types="../../../index" />
export declare type SdkScmPdsModule = $.kd.sdk.scm.pds.SdkScmPdsModule;
export declare const SdkScmPdsModule: $.kd.sdk.scm.pds.SdkScmPdsModule_C;
