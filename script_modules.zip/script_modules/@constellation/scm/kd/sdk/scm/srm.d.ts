/// <reference types="../../../index" />
export declare type SdkScmSrmModule = $.kd.sdk.scm.srm.SdkScmSrmModule;
export declare const SdkScmSrmModule: $.kd.sdk.scm.srm.SdkScmSrmModule_C;
