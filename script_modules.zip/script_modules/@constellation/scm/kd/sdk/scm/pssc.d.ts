/// <reference types="../../../index" />
export declare type SdkScmPsscModule = $.kd.sdk.scm.pssc.SdkScmPsscModule;
export declare const SdkScmPsscModule: $.kd.sdk.scm.pssc.SdkScmPsscModule_C;
