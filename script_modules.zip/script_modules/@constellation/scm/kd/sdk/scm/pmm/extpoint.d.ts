/// <reference types="../../../../index" />
export declare type IOperateMonitorRuleService = $.kd.sdk.scm.pmm.extpoint.IOperateMonitorRuleService;
export declare const IOperateMonitorRuleService: $.kd.sdk.scm.pmm.extpoint.IOperateMonitorRuleService;
