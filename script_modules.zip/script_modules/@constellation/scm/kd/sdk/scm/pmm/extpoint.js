export const IOperateMonitorRuleService = $.type("kd.sdk.scm.pmm.extpoint.IOperateMonitorRuleService");
