export const IQuoInquiryVerify = $.type("kd.sdk.scm.quo.extpoint.IQuoInquiryVerify");
