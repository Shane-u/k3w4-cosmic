/// <reference types="../../../../index" />
export declare type IQuoInquiryVerify = $.kd.sdk.scm.quo.extpoint.IQuoInquiryVerify;
export declare const IQuoInquiryVerify: $.kd.sdk.scm.quo.extpoint.IQuoInquiryVerify;
