export const SdkScmSrmModule = $.type("kd.sdk.scm.srm.SdkScmSrmModule");
