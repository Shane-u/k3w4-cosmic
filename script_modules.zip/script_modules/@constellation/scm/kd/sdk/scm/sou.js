export const SdkScmSouModule = $.type("kd.sdk.scm.sou.SdkScmSouModule");
