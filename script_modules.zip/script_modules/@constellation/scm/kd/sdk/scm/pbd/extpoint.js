export const IBusinessRulesCallBackService = $.type("kd.sdk.scm.pbd.extpoint.IBusinessRulesCallBackService");
export const IBusinessRulesCheckParseService = $.type("kd.sdk.scm.pbd.extpoint.IBusinessRulesCheckParseService");
export const IBusinessRulesFillParseService = $.type("kd.sdk.scm.pbd.extpoint.IBusinessRulesFillParseService");
export const IBusinessRulesRequestParseService = $.type("kd.sdk.scm.pbd.extpoint.IBusinessRulesRequestParseService");
