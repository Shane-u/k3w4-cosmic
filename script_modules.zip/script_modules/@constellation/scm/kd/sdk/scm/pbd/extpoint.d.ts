/// <reference types="../../../../index" />
export declare type IBusinessRulesCallBackService = $.kd.sdk.scm.pbd.extpoint.IBusinessRulesCallBackService;
export declare const IBusinessRulesCallBackService: $.kd.sdk.scm.pbd.extpoint.IBusinessRulesCallBackService;
export declare type IBusinessRulesCheckParseService = $.kd.sdk.scm.pbd.extpoint.IBusinessRulesCheckParseService;
export declare const IBusinessRulesCheckParseService: $.kd.sdk.scm.pbd.extpoint.IBusinessRulesCheckParseService;
export declare type IBusinessRulesFillParseService = $.kd.sdk.scm.pbd.extpoint.IBusinessRulesFillParseService;
export declare const IBusinessRulesFillParseService: $.kd.sdk.scm.pbd.extpoint.IBusinessRulesFillParseService;
export declare type IBusinessRulesRequestParseService = $.kd.sdk.scm.pbd.extpoint.IBusinessRulesRequestParseService;
export declare const IBusinessRulesRequestParseService: $.kd.sdk.scm.pbd.extpoint.IBusinessRulesRequestParseService;
