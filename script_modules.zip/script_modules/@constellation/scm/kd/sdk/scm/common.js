export const SdkScmCommonModule = $.type("kd.sdk.scm.common.SdkScmCommonModule");
