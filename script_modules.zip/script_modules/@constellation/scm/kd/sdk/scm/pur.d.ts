/// <reference types="../../../index" />
export declare type SdkScmPurModule = $.kd.sdk.scm.pur.SdkScmPurModule;
export declare const SdkScmPurModule: $.kd.sdk.scm.pur.SdkScmPurModule_C;
