export const SdkScmMalModule = $.type("kd.sdk.scm.mal.SdkScmMalModule");
