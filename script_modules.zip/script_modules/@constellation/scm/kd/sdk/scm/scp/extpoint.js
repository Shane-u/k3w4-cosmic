export const IAutoStockSupport = $.type("kd.sdk.scm.scp.extpoint.IAutoStockSupport");
export const IScpHandCheckSupport = $.type("kd.sdk.scm.scp.extpoint.IScpHandCheckSupport");
export const IScpInvoiceCloudSupport = $.type("kd.sdk.scm.scp.extpoint.IScpInvoiceCloudSupport");
export const IScpOrderChangeSupport = $.type("kd.sdk.scm.scp.extpoint.IScpOrderChangeSupport");
