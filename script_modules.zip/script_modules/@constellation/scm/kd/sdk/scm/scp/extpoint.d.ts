/// <reference types="../../../../index" />
export declare type IAutoStockSupport = $.kd.sdk.scm.scp.extpoint.IAutoStockSupport;
export declare const IAutoStockSupport: $.kd.sdk.scm.scp.extpoint.IAutoStockSupport;
export declare type IScpHandCheckSupport = $.kd.sdk.scm.scp.extpoint.IScpHandCheckSupport;
export declare const IScpHandCheckSupport: $.kd.sdk.scm.scp.extpoint.IScpHandCheckSupport;
export declare type IScpInvoiceCloudSupport = $.kd.sdk.scm.scp.extpoint.IScpInvoiceCloudSupport;
export declare const IScpInvoiceCloudSupport: $.kd.sdk.scm.scp.extpoint.IScpInvoiceCloudSupport;
export declare type IScpOrderChangeSupport = $.kd.sdk.scm.scp.extpoint.IScpOrderChangeSupport;
export declare const IScpOrderChangeSupport: $.kd.sdk.scm.scp.extpoint.IScpOrderChangeSupport;
