export const AdoptionRule = $.type("kd.sdk.scm.sou.entity.AdoptionRule");
export const SouCompareAssiRecentPriceArgs = $.type("kd.sdk.scm.sou.entity.SouCompareAssiRecentPriceArgs");
export const SouCompareAssistantDoingArgs = $.type("kd.sdk.scm.sou.entity.SouCompareAssistantDoingArgs");
