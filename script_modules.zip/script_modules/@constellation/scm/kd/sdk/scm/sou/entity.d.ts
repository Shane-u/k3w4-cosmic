/// <reference types="../../../../index" />
export declare type AdoptionRule = $.kd.sdk.scm.sou.entity.AdoptionRule;
export declare const AdoptionRule: $.kd.sdk.scm.sou.entity.AdoptionRule_C;
export declare type SouCompareAssiRecentPriceArgs = $.kd.sdk.scm.sou.entity.SouCompareAssiRecentPriceArgs;
export declare const SouCompareAssiRecentPriceArgs: $.kd.sdk.scm.sou.entity.SouCompareAssiRecentPriceArgs_C;
export declare type SouCompareAssistantDoingArgs = $.kd.sdk.scm.sou.entity.SouCompareAssistantDoingArgs;
export declare const SouCompareAssistantDoingArgs: $.kd.sdk.scm.sou.entity.SouCompareAssistantDoingArgs_C;
