/// <reference types="../../../../index" />
export declare type ISouBidBillToEasXKOrder = $.kd.sdk.scm.sou.extpoint.ISouBidBillToEasXKOrder;
export declare const ISouBidBillToEasXKOrder: $.kd.sdk.scm.sou.extpoint.ISouBidBillToEasXKOrder;
export declare type ISouCompareAssistantDataSource = $.kd.sdk.scm.sou.extpoint.ISouCompareAssistantDataSource;
export declare const ISouCompareAssistantDataSource: $.kd.sdk.scm.sou.extpoint.ISouCompareAssistantDataSource;
export declare type ISouCompareAssistantRecentPriceSource = $.kd.sdk.scm.sou.extpoint.ISouCompareAssistantRecentPriceSource;
export declare const ISouCompareAssistantRecentPriceSource: $.kd.sdk.scm.sou.extpoint.ISouCompareAssistantRecentPriceSource;
export declare type ISouComparePushNoticeVerify = $.kd.sdk.scm.sou.extpoint.ISouComparePushNoticeVerify;
export declare const ISouComparePushNoticeVerify: $.kd.sdk.scm.sou.extpoint.ISouComparePushNoticeVerify;
export declare type ISouCompareToEasXKOrder = $.kd.sdk.scm.sou.extpoint.ISouCompareToEasXKOrder;
export declare const ISouCompareToEasXKOrder: $.kd.sdk.scm.sou.extpoint.ISouCompareToEasXKOrder;
export declare type ISouCompareToolAdopt = $.kd.sdk.scm.sou.extpoint.ISouCompareToolAdopt;
export declare const ISouCompareToolAdopt: $.kd.sdk.scm.sou.extpoint.ISouCompareToolAdopt;
export declare type ISouCompareToolSupColumn = $.kd.sdk.scm.sou.extpoint.ISouCompareToolSupColumn;
export declare const ISouCompareToolSupColumn: $.kd.sdk.scm.sou.extpoint.ISouCompareToolSupColumn;
