export const ISouBidBillToEasXKOrder = $.type("kd.sdk.scm.sou.extpoint.ISouBidBillToEasXKOrder");
export const ISouCompareAssistantDataSource = $.type("kd.sdk.scm.sou.extpoint.ISouCompareAssistantDataSource");
export const ISouCompareAssistantRecentPriceSource = $.type("kd.sdk.scm.sou.extpoint.ISouCompareAssistantRecentPriceSource");
export const ISouComparePushNoticeVerify = $.type("kd.sdk.scm.sou.extpoint.ISouComparePushNoticeVerify");
export const ISouCompareToEasXKOrder = $.type("kd.sdk.scm.sou.extpoint.ISouCompareToEasXKOrder");
export const ISouCompareToolAdopt = $.type("kd.sdk.scm.sou.extpoint.ISouCompareToolAdopt");
export const ISouCompareToolSupColumn = $.type("kd.sdk.scm.sou.extpoint.ISouCompareToolSupColumn");
