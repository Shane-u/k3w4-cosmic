export const SdkScmScpModule = $.type("kd.sdk.scm.scp.SdkScmScpModule");
