/// <reference types="../../../index" />
export declare type SdkScmScpModule = $.kd.sdk.scm.scp.SdkScmScpModule;
export declare const SdkScmScpModule: $.kd.sdk.scm.scp.SdkScmScpModule_C;
