/// <reference types="../../../../../index" />
export declare type AbstractSrmPortraitDataSetStatistic = $.kd.sdk.scm.srm.extpoint.portait.AbstractSrmPortraitDataSetStatistic;
export declare const AbstractSrmPortraitDataSetStatistic: $.kd.sdk.scm.srm.extpoint.portait.AbstractSrmPortraitDataSetStatistic_C;
