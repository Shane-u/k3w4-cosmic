export const SrmPortraitContext = $.type("kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitContext");
export const SrmPortraitStatisticInfo = $.type("kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitStatisticInfo");
