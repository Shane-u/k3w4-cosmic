export const AbstractSrmPortraitDataSetStatistic = $.type("kd.sdk.scm.srm.extpoint.portait.AbstractSrmPortraitDataSetStatistic");
