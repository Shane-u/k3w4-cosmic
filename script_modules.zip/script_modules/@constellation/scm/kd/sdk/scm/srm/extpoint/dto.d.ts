/// <reference types="../../../../../index" />
export declare type SrmAutoScoreReq = $.kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreReq;
export declare const SrmAutoScoreReq: $.kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreReq_C;
export declare type SrmAutoScoreResp = $.kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreResp;
export declare const SrmAutoScoreResp: $.kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreResp_C;
