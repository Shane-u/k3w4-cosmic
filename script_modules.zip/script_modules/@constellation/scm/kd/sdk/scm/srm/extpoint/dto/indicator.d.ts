/// <reference types="../../../../../../index" />
export declare type SrmPortraitContext = $.kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitContext;
export declare const SrmPortraitContext: $.kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitContext_C;
export declare type SrmPortraitStatisticInfo = $.kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitStatisticInfo;
export declare const SrmPortraitStatisticInfo: $.kd.sdk.scm.srm.extpoint.dto.indicator.SrmPortraitStatisticInfo_C;
