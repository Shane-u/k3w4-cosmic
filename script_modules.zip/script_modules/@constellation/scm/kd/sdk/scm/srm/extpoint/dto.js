export const SrmAutoScoreReq = $.type("kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreReq");
export const SrmAutoScoreResp = $.type("kd.sdk.scm.srm.extpoint.dto.SrmAutoScoreResp");
