/// <reference types="../../../index" />
export declare type SdkScmSouModule = $.kd.sdk.scm.sou.SdkScmSouModule;
export declare const SdkScmSouModule: $.kd.sdk.scm.sou.SdkScmSouModule_C;
