/// <reference types="../../../index" />
export declare type SdkScmPmmModule = $.kd.sdk.scm.pmm.SdkScmPmmModule;
export declare const SdkScmPmmModule: $.kd.sdk.scm.pmm.SdkScmPmmModule_C;
