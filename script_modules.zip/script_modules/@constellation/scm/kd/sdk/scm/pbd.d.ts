/// <reference types="../../../index" />
export declare type SdkScmPbdModule = $.kd.sdk.scm.pbd.SdkScmPbdModule;
export declare const SdkScmPbdModule: $.kd.sdk.scm.pbd.SdkScmPbdModule_C;
