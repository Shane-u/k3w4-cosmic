export const SdkScmQuoModule = $.type("kd.sdk.scm.quo.SdkScmQuoModule");
