export const SdkScmPbdModule = $.type("kd.sdk.scm.pbd.SdkScmPbdModule");
