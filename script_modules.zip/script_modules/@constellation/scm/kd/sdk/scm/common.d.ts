/// <reference types="../../../index" />
export declare type SdkScmCommonModule = $.kd.sdk.scm.common.SdkScmCommonModule;
export declare const SdkScmCommonModule: $.kd.sdk.scm.common.SdkScmCommonModule_C;
