export const IPsscTaskSplitBillBasis = $.type("kd.sdk.scm.pssc.task.IPsscTaskSplitBillBasis");
export const IReqContactOrderHandler = $.type("kd.sdk.scm.pssc.task.IReqContactOrderHandler");
