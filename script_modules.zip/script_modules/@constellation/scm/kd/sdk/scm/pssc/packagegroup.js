export const IPsscPackageGroupPrepareExecutor = $.type("kd.sdk.scm.pssc.packagegroup.IPsscPackageGroupPrepareExecutor");
