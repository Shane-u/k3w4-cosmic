/// <reference types="../../../../index" />
export declare type IPsscPackageGroupPrepareExecutor = $.kd.sdk.scm.pssc.packagegroup.IPsscPackageGroupPrepareExecutor;
export declare const IPsscPackageGroupPrepareExecutor: $.kd.sdk.scm.pssc.packagegroup.IPsscPackageGroupPrepareExecutor;
