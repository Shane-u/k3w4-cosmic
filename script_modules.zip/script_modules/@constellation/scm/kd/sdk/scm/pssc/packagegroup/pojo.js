export const PsscMaterialGroupInfo = $.type("kd.sdk.scm.pssc.packagegroup.pojo.PsscMaterialGroupInfo");
export const PsscPackageGroupContext = $.type("kd.sdk.scm.pssc.packagegroup.pojo.PsscPackageGroupContext");
export const PsscTagGroupRuleOrderInfo = $.type("kd.sdk.scm.pssc.packagegroup.pojo.PsscTagGroupRuleOrderInfo");
