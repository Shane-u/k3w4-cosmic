/// <reference types="../../../../../index" />
export declare type PsscMaterialGroupInfo = $.kd.sdk.scm.pssc.packagegroup.pojo.PsscMaterialGroupInfo;
export declare const PsscMaterialGroupInfo: $.kd.sdk.scm.pssc.packagegroup.pojo.PsscMaterialGroupInfo_C;
export declare type PsscPackageGroupContext = $.kd.sdk.scm.pssc.packagegroup.pojo.PsscPackageGroupContext;
export declare const PsscPackageGroupContext: $.kd.sdk.scm.pssc.packagegroup.pojo.PsscPackageGroupContext_C;
export declare type PsscTagGroupRuleOrderInfo = $.kd.sdk.scm.pssc.packagegroup.pojo.PsscTagGroupRuleOrderInfo;
export declare const PsscTagGroupRuleOrderInfo: $.kd.sdk.scm.pssc.packagegroup.pojo.PsscTagGroupRuleOrderInfo_C;
