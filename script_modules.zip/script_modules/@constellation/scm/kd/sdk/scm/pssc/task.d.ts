/// <reference types="../../../../index" />
export declare type IPsscTaskSplitBillBasis = $.kd.sdk.scm.pssc.task.IPsscTaskSplitBillBasis;
export declare const IPsscTaskSplitBillBasis: $.kd.sdk.scm.pssc.task.IPsscTaskSplitBillBasis;
export declare type IReqContactOrderHandler = $.kd.sdk.scm.pssc.task.IReqContactOrderHandler;
export declare const IReqContactOrderHandler: $.kd.sdk.scm.pssc.task.IReqContactOrderHandler;
