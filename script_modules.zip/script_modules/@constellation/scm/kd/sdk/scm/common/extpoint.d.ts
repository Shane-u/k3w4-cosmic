/// <reference types="../../../../index" />
export declare type ICreateUserNumberSupport = $.kd.sdk.scm.common.extpoint.ICreateUserNumberSupport;
export declare const ICreateUserNumberSupport: $.kd.sdk.scm.common.extpoint.ICreateUserNumberSupport;
export declare type IMaterialGroupStandardService = $.kd.sdk.scm.common.extpoint.IMaterialGroupStandardService;
export declare const IMaterialGroupStandardService: $.kd.sdk.scm.common.extpoint.IMaterialGroupStandardService;
export declare type IPurInstockCheckMappingService = $.kd.sdk.scm.common.extpoint.IPurInstockCheckMappingService;
export declare const IPurInstockCheckMappingService: $.kd.sdk.scm.common.extpoint.IPurInstockCheckMappingService;
export declare type ISrmSupChgInfoTypeInter = $.kd.sdk.scm.common.extpoint.ISrmSupChgInfoTypeInter;
export declare const ISrmSupChgInfoTypeInter: $.kd.sdk.scm.common.extpoint.ISrmSupChgInfoTypeInter;
export declare type ISupChgFilterService = $.kd.sdk.scm.common.extpoint.ISupChgFilterService;
export declare const ISupChgFilterService: $.kd.sdk.scm.common.extpoint.ISupChgFilterService;
export declare type ISupplierGroupStandardService = $.kd.sdk.scm.common.extpoint.ISupplierGroupStandardService;
export declare const ISupplierGroupStandardService: $.kd.sdk.scm.common.extpoint.ISupplierGroupStandardService;
export declare type ITransferDataSupport = $.kd.sdk.scm.common.extpoint.ITransferDataSupport;
export declare const ITransferDataSupport: $.kd.sdk.scm.common.extpoint.ITransferDataSupport;
