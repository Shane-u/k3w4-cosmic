export const ICreateUserNumberSupport = $.type("kd.sdk.scm.common.extpoint.ICreateUserNumberSupport");
export const IMaterialGroupStandardService = $.type("kd.sdk.scm.common.extpoint.IMaterialGroupStandardService");
export const IPurInstockCheckMappingService = $.type("kd.sdk.scm.common.extpoint.IPurInstockCheckMappingService");
export const ISrmSupChgInfoTypeInter = $.type("kd.sdk.scm.common.extpoint.ISrmSupChgInfoTypeInter");
export const ISupChgFilterService = $.type("kd.sdk.scm.common.extpoint.ISupChgFilterService");
export const ISupplierGroupStandardService = $.type("kd.sdk.scm.common.extpoint.ISupplierGroupStandardService");
export const ITransferDataSupport = $.type("kd.sdk.scm.common.extpoint.ITransferDataSupport");
