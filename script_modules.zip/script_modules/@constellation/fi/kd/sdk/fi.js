export const SdkFiModule = $.type("kd.sdk.fi.SdkFiModule");
