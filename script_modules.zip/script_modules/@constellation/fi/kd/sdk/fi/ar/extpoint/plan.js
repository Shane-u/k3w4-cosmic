export const IPlanRowSplit = $.type("kd.sdk.fi.ar.extpoint.plan.IPlanRowSplit");
