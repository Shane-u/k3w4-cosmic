export const IInvIssueCallback = $.type("kd.sdk.fi.ar.extpoint.invoice.IInvIssueCallback");
