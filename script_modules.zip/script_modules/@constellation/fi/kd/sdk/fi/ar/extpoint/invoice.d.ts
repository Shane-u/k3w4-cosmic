export declare type IInvIssueCallback = $.kd.sdk.fi.ar.extpoint.invoice.IInvIssueCallback;
export declare const IInvIssueCallback: $.kd.sdk.fi.ar.extpoint.invoice.IInvIssueCallback;
