export declare type IPlanRowSplit = $.kd.sdk.fi.ar.extpoint.plan.IPlanRowSplit;
export declare const IPlanRowSplit: $.kd.sdk.fi.ar.extpoint.plan.IPlanRowSplit;
