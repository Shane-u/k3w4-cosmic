export const IAttachmentHandler = $.type("kd.sdk.fi.fgptas.extpoint.attachment.IAttachmentHandler");
export const IPictureAnalysis = $.type("kd.sdk.fi.fgptas.extpoint.attachment.IPictureAnalysis");
