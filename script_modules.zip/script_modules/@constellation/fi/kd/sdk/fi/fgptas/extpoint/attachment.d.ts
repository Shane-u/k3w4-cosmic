export declare type IAttachmentHandler = $.kd.sdk.fi.fgptas.extpoint.attachment.IAttachmentHandler;
export declare const IAttachmentHandler: $.kd.sdk.fi.fgptas.extpoint.attachment.IAttachmentHandler;
export declare type IPictureAnalysis = $.kd.sdk.fi.fgptas.extpoint.attachment.IPictureAnalysis;
export declare const IPictureAnalysis: $.kd.sdk.fi.fgptas.extpoint.attachment.IPictureAnalysis;
