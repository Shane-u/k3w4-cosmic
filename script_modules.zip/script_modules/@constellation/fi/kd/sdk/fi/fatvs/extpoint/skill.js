export const ISkillRunnableExtPlugin = $.type("kd.sdk.fi.fatvs.extpoint.skill.ISkillRunnableExtPlugin");
