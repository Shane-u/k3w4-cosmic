export declare type ISkillRunnableExtPlugin = $.kd.sdk.fi.fatvs.extpoint.skill.ISkillRunnableExtPlugin;
export declare const ISkillRunnableExtPlugin: $.kd.sdk.fi.fatvs.extpoint.skill.ISkillRunnableExtPlugin;
