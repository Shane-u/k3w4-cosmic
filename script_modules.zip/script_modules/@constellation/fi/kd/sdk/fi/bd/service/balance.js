export const BalanceExecutorSdk = $.type("kd.sdk.fi.bd.service.balance.BalanceExecutorSdk");
