export declare type CDCServiceGLIntegratorSDK = $.kd.sdk.fi.bd.service.cdc.CDCServiceGLIntegratorSDK;
export declare const CDCServiceGLIntegratorSDK: $.kd.sdk.fi.bd.service.cdc.CDCServiceGLIntegratorSDK_C;
