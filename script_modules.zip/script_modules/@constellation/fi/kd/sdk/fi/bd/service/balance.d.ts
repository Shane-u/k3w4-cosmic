export declare type BalanceExecutorSdk = $.kd.sdk.fi.bd.service.balance.BalanceExecutorSdk;
export declare const BalanceExecutorSdk: $.kd.sdk.fi.bd.service.balance.BalanceExecutorSdk_C;
