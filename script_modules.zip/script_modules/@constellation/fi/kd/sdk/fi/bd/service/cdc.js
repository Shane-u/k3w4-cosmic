export const CDCServiceGLIntegratorSDK = $.type("kd.sdk.fi.bd.service.cdc.CDCServiceGLIntegratorSDK");
