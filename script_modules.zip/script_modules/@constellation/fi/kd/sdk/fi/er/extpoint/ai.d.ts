export declare type IAIReimburseService = $.kd.sdk.fi.er.extpoint.ai.IAIReimburseService;
export declare const IAIReimburseService: $.kd.sdk.fi.er.extpoint.ai.IAIReimburseService;
