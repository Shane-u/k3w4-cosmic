export declare type ITripCheckOrderUserStatusService = $.kd.sdk.fi.er.extpoint.trip.ITripCheckOrderUserStatusService;
export declare const ITripCheckOrderUserStatusService: $.kd.sdk.fi.er.extpoint.trip.ITripCheckOrderUserStatusService;
export declare type ITripCheckReqBillCloseService = $.kd.sdk.fi.er.extpoint.trip.ITripCheckReqBillCloseService;
export declare const ITripCheckReqBillCloseService: $.kd.sdk.fi.er.extpoint.trip.ITripCheckReqBillCloseService;
export declare type ITripOrderUpdateReimService = $.kd.sdk.fi.er.extpoint.trip.ITripOrderUpdateReimService;
export declare const ITripOrderUpdateReimService: $.kd.sdk.fi.er.extpoint.trip.ITripOrderUpdateReimService;
