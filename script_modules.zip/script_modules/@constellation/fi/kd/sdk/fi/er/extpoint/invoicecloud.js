export const AfterSelectInvoice = $.type("kd.sdk.fi.er.extpoint.invoicecloud.AfterSelectInvoice");
export const IAfterHandleBillPool = $.type("kd.sdk.fi.er.extpoint.invoicecloud.IAfterHandleBillPool");
export const IBeforeHandleBillPoolParamPrepare = $.type("kd.sdk.fi.er.extpoint.invoicecloud.IBeforeHandleBillPoolParamPrepare");
