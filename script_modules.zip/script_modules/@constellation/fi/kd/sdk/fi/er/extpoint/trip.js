export const ITripCheckOrderUserStatusService = $.type("kd.sdk.fi.er.extpoint.trip.ITripCheckOrderUserStatusService");
export const ITripCheckReqBillCloseService = $.type("kd.sdk.fi.er.extpoint.trip.ITripCheckReqBillCloseService");
export const ITripOrderUpdateReimService = $.type("kd.sdk.fi.er.extpoint.trip.ITripOrderUpdateReimService");
