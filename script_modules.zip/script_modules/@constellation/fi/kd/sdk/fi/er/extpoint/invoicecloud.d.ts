export declare type AfterSelectInvoice = $.kd.sdk.fi.er.extpoint.invoicecloud.AfterSelectInvoice;
export declare const AfterSelectInvoice: $.kd.sdk.fi.er.extpoint.invoicecloud.AfterSelectInvoice;
export declare type IAfterHandleBillPool = $.kd.sdk.fi.er.extpoint.invoicecloud.IAfterHandleBillPool;
export declare const IAfterHandleBillPool: $.kd.sdk.fi.er.extpoint.invoicecloud.IAfterHandleBillPool;
export declare type IBeforeHandleBillPoolParamPrepare = $.kd.sdk.fi.er.extpoint.invoicecloud.IBeforeHandleBillPoolParamPrepare;
export declare const IBeforeHandleBillPoolParamPrepare: $.kd.sdk.fi.er.extpoint.invoicecloud.IBeforeHandleBillPoolParamPrepare;
