export declare type IDrawRuleService = $.kd.sdk.fi.er.extpoint.draw.IDrawRuleService;
export declare const IDrawRuleService: $.kd.sdk.fi.er.extpoint.draw.IDrawRuleService;
