export const IAIReimburseService = $.type("kd.sdk.fi.er.extpoint.ai.IAIReimburseService");
