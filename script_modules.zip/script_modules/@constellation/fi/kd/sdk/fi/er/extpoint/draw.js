export const IDrawRuleService = $.type("kd.sdk.fi.er.extpoint.draw.IDrawRuleService");
