export declare type ISynchronizationDataExtPlugin = $.kd.sdk.fi.dhc.extpoint.ISynchronizationDataExtPlugin;
export declare const ISynchronizationDataExtPlugin: $.kd.sdk.fi.dhc.extpoint.ISynchronizationDataExtPlugin;
