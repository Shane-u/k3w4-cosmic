export const ISynchronizationDataExtPlugin = $.type("kd.sdk.fi.dhc.extpoint.ISynchronizationDataExtPlugin");
