export declare type ITranSupBillVoucher = $.kd.sdk.fi.fca.extpoint.ITranSupBillVoucher;
export declare const ITranSupBillVoucher: $.kd.sdk.fi.fca.extpoint.ITranSupBillVoucher;
