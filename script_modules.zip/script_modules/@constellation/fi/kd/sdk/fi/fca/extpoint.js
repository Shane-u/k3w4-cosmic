export const ITranSupBillVoucher = $.type("kd.sdk.fi.fca.extpoint.ITranSupBillVoucher");
