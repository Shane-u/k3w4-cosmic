export declare type CheckContext = $.kd.sdk.fi.fcm.extpoint.checkitem.CheckContext;
export declare const CheckContext: $.kd.sdk.fi.fcm.extpoint.checkitem.CheckContext_C;
export declare type CheckResult = $.kd.sdk.fi.fcm.extpoint.checkitem.CheckResult;
export declare const CheckResult: $.kd.sdk.fi.fcm.extpoint.checkitem.CheckResult_C;
export declare type IClosePeriodCheckPlugin = $.kd.sdk.fi.fcm.extpoint.checkitem.IClosePeriodCheckPlugin;
export declare const IClosePeriodCheckPlugin: $.kd.sdk.fi.fcm.extpoint.checkitem.IClosePeriodCheckPlugin;
