export const CheckContext = $.type("kd.sdk.fi.fcm.extpoint.checkitem.CheckContext");
export const CheckResult = $.type("kd.sdk.fi.fcm.extpoint.checkitem.CheckResult");
export const IClosePeriodCheckPlugin = $.type("kd.sdk.fi.fcm.extpoint.checkitem.IClosePeriodCheckPlugin");
