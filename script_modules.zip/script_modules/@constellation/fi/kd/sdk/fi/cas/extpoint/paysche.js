export const IPayScheSecondaryFieldFill = $.type("kd.sdk.fi.cas.extpoint.paysche.IPayScheSecondaryFieldFill");
