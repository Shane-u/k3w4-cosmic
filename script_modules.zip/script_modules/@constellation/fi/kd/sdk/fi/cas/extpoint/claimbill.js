export const BankAutoMatchCheck = $.type("kd.sdk.fi.cas.extpoint.claimbill.BankAutoMatchCheck");
export const IClaimHandlePluginSDK = $.type("kd.sdk.fi.cas.extpoint.claimbill.IClaimHandlePluginSDK");
export const IClaimbillFilter = $.type("kd.sdk.fi.cas.extpoint.claimbill.IClaimbillFilter");
export const IClaimcenterHote = $.type("kd.sdk.fi.cas.extpoint.claimbill.IClaimcenterHote");
