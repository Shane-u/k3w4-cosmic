export declare type IAgentPayField = $.kd.sdk.fi.cas.extpoint.recbill.IAgentPayField;
export declare const IAgentPayField: $.kd.sdk.fi.cas.extpoint.recbill.IAgentPayField;
export declare type IRecbillFilter = $.kd.sdk.fi.cas.extpoint.recbill.IRecbillFilter;
export declare const IRecbillFilter: $.kd.sdk.fi.cas.extpoint.recbill.IRecbillFilter;
