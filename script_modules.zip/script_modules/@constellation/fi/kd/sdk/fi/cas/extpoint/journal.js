export const IJournalVoucherBookInterface = $.type("kd.sdk.fi.cas.extpoint.journal.IJournalVoucherBookInterface");
