export declare type ICheckArchiveBillTypeInterface = $.kd.sdk.fi.cas.extpoint.closeperiod.ICheckArchiveBillTypeInterface;
export declare const ICheckArchiveBillTypeInterface: $.kd.sdk.fi.cas.extpoint.closeperiod.ICheckArchiveBillTypeInterface;
