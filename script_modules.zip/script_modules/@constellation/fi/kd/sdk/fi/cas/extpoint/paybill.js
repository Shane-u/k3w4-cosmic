export const IGenBankBillSDKService = $.type("kd.sdk.fi.cas.extpoint.paybill.IGenBankBillSDKService");
export const IPaybillWriteback = $.type("kd.sdk.fi.cas.extpoint.paybill.IPaybillWriteback");
export const IPayeeBankInfoFilter = $.type("kd.sdk.fi.cas.extpoint.paybill.IPayeeBankInfoFilter");
