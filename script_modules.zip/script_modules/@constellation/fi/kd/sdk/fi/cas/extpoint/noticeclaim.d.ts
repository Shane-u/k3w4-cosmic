export declare type INoticeClaimSchemeInterface = $.kd.sdk.fi.cas.extpoint.noticeclaim.INoticeClaimSchemeInterface;
export declare const INoticeClaimSchemeInterface: $.kd.sdk.fi.cas.extpoint.noticeclaim.INoticeClaimSchemeInterface;
