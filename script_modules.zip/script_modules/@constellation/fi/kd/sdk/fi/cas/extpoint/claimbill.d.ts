export declare type BankAutoMatchCheck = $.kd.sdk.fi.cas.extpoint.claimbill.BankAutoMatchCheck;
export declare const BankAutoMatchCheck: $.kd.sdk.fi.cas.extpoint.claimbill.BankAutoMatchCheck;
export declare type IClaimHandlePluginSDK = $.kd.sdk.fi.cas.extpoint.claimbill.IClaimHandlePluginSDK;
export declare const IClaimHandlePluginSDK: $.kd.sdk.fi.cas.extpoint.claimbill.IClaimHandlePluginSDK;
export declare type IClaimbillFilter = $.kd.sdk.fi.cas.extpoint.claimbill.IClaimbillFilter;
export declare const IClaimbillFilter: $.kd.sdk.fi.cas.extpoint.claimbill.IClaimbillFilter;
export declare type IClaimcenterHote = $.kd.sdk.fi.cas.extpoint.claimbill.IClaimcenterHote;
export declare const IClaimcenterHote: $.kd.sdk.fi.cas.extpoint.claimbill.IClaimcenterHote;
