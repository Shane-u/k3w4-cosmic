export const IAgentPayField = $.type("kd.sdk.fi.cas.extpoint.recbill.IAgentPayField");
export const IRecbillFilter = $.type("kd.sdk.fi.cas.extpoint.recbill.IRecbillFilter");
