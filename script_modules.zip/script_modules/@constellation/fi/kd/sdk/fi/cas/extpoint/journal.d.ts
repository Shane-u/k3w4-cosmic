export declare type IJournalVoucherBookInterface = $.kd.sdk.fi.cas.extpoint.journal.IJournalVoucherBookInterface;
export declare const IJournalVoucherBookInterface: $.kd.sdk.fi.cas.extpoint.journal.IJournalVoucherBookInterface;
