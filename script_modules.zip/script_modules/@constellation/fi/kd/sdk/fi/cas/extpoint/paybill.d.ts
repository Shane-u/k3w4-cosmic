export declare type IGenBankBillSDKService = $.kd.sdk.fi.cas.extpoint.paybill.IGenBankBillSDKService;
export declare const IGenBankBillSDKService: $.kd.sdk.fi.cas.extpoint.paybill.IGenBankBillSDKService;
export declare type IPaybillWriteback = $.kd.sdk.fi.cas.extpoint.paybill.IPaybillWriteback;
export declare const IPaybillWriteback: $.kd.sdk.fi.cas.extpoint.paybill.IPaybillWriteback;
export declare type IPayeeBankInfoFilter = $.kd.sdk.fi.cas.extpoint.paybill.IPayeeBankInfoFilter;
export declare const IPayeeBankInfoFilter: $.kd.sdk.fi.cas.extpoint.paybill.IPayeeBankInfoFilter;
