export const INoticeClaimSchemeInterface = $.type("kd.sdk.fi.cas.extpoint.noticeclaim.INoticeClaimSchemeInterface");
