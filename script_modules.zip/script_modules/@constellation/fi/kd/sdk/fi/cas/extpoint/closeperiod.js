export const ICheckArchiveBillTypeInterface = $.type("kd.sdk.fi.cas.extpoint.closeperiod.ICheckArchiveBillTypeInterface");
