export declare type IPayScheSecondaryFieldFill = $.kd.sdk.fi.cas.extpoint.paysche.IPayScheSecondaryFieldFill;
export declare const IPayScheSecondaryFieldFill: $.kd.sdk.fi.cas.extpoint.paysche.IPayScheSecondaryFieldFill;
