export declare type INoticeCheck = $.kd.sdk.fi.gl.extpoint.notice.INoticeCheck;
export declare const INoticeCheck: $.kd.sdk.fi.gl.extpoint.notice.INoticeCheck;
export declare type INoticeVoucherIdsProvider = $.kd.sdk.fi.gl.extpoint.notice.INoticeVoucherIdsProvider;
export declare const INoticeVoucherIdsProvider: $.kd.sdk.fi.gl.extpoint.notice.INoticeVoucherIdsProvider;
export declare type INoticeVoucherSourceType = $.kd.sdk.fi.gl.extpoint.notice.INoticeVoucherSourceType;
export declare const INoticeVoucherSourceType: $.kd.sdk.fi.gl.extpoint.notice.INoticeVoucherSourceType;
