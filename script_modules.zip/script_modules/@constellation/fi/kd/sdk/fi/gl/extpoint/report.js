export const IReportColumnSetting = $.type("kd.sdk.fi.gl.extpoint.report.IReportColumnSetting");
export const IReportQuery = $.type("kd.sdk.fi.gl.extpoint.report.IReportQuery");
export const IReportRowHideSpi = $.type("kd.sdk.fi.gl.extpoint.report.IReportRowHideSpi");
export const ReportParam = $.type("kd.sdk.fi.gl.extpoint.report.ReportParam");
export const RowType = $.type("kd.sdk.fi.gl.extpoint.report.RowType");
