export declare type IAmountAllocate = $.kd.sdk.fi.gl.extpoint.amort.IAmountAllocate;
export declare const IAmountAllocate: $.kd.sdk.fi.gl.extpoint.amort.IAmountAllocate;
