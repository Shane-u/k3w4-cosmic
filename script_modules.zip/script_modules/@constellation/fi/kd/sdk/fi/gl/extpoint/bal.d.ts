export declare type IAcctBalCalculator = $.kd.sdk.fi.gl.extpoint.bal.IAcctBalCalculator;
export declare const IAcctBalCalculator: $.kd.sdk.fi.gl.extpoint.bal.IAcctBalCalculator;
export declare type ICFBalCalculator = $.kd.sdk.fi.gl.extpoint.bal.ICFBalCalculator;
export declare const ICFBalCalculator: $.kd.sdk.fi.gl.extpoint.bal.ICFBalCalculator;
