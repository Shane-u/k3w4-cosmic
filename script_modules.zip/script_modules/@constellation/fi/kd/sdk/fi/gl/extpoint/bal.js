export const IAcctBalCalculator = $.type("kd.sdk.fi.gl.extpoint.bal.IAcctBalCalculator");
export const ICFBalCalculator = $.type("kd.sdk.fi.gl.extpoint.bal.ICFBalCalculator");
