export const INoticeCheck = $.type("kd.sdk.fi.gl.extpoint.notice.INoticeCheck");
export const INoticeVoucherIdsProvider = $.type("kd.sdk.fi.gl.extpoint.notice.INoticeVoucherIdsProvider");
export const INoticeVoucherSourceType = $.type("kd.sdk.fi.gl.extpoint.notice.INoticeVoucherSourceType");
