export const IAmountAllocate = $.type("kd.sdk.fi.gl.extpoint.amort.IAmountAllocate");
