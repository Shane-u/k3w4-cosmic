export declare type IAccountAssgrpMapping = $.kd.sdk.fi.gl.extpoint.syncbookvch.IAccountAssgrpMapping;
export declare const IAccountAssgrpMapping: $.kd.sdk.fi.gl.extpoint.syncbookvch.IAccountAssgrpMapping;
