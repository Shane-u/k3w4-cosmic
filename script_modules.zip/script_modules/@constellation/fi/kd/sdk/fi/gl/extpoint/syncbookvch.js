export const IAccountAssgrpMapping = $.type("kd.sdk.fi.gl.extpoint.syncbookvch.IAccountAssgrpMapping");
