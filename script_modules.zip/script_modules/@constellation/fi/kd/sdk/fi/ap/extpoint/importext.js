export const IAfterImportDataExt = $.type("kd.sdk.fi.ap.extpoint.importext.IAfterImportDataExt");
