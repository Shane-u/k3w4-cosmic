export const IAfterWoffProcess = $.type("kd.sdk.fi.ap.extpoint.woff.IAfterWoffProcess");
export const IWoffMatchExt = $.type("kd.sdk.fi.ap.extpoint.woff.IWoffMatchExt");
