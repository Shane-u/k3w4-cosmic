export declare type IInvoiceImport = $.kd.sdk.fi.ap.extpoint.invoice.IInvoiceImport;
export declare const IInvoiceImport: $.kd.sdk.fi.ap.extpoint.invoice.IInvoiceImport;
