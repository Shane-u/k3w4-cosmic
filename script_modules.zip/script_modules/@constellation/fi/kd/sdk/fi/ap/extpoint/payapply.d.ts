export declare type ICasPayBillPayCallback = $.kd.sdk.fi.ap.extpoint.payapply.ICasPayBillPayCallback;
export declare const ICasPayBillPayCallback: $.kd.sdk.fi.ap.extpoint.payapply.ICasPayBillPayCallback;
