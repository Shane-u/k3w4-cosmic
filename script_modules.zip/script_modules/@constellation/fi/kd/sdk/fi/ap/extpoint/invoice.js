export const IInvoiceImport = $.type("kd.sdk.fi.ap.extpoint.invoice.IInvoiceImport");
