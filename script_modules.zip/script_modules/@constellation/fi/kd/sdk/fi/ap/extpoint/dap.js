export const IAfterGenerateVoucherExt = $.type("kd.sdk.fi.ap.extpoint.dap.IAfterGenerateVoucherExt");
