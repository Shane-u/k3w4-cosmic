export declare type IAfterBizProcess = $.kd.sdk.fi.ap.extpoint.list.IAfterBizProcess;
export declare const IAfterBizProcess: $.kd.sdk.fi.ap.extpoint.list.IAfterBizProcess;
export declare type IApproverSetting = $.kd.sdk.fi.ap.extpoint.list.IApproverSetting;
export declare const IApproverSetting: $.kd.sdk.fi.ap.extpoint.list.IApproverSetting;
export declare type IPayeeBankInfoFilter = $.kd.sdk.fi.ap.extpoint.list.IPayeeBankInfoFilter;
export declare const IPayeeBankInfoFilter: $.kd.sdk.fi.ap.extpoint.list.IPayeeBankInfoFilter;
