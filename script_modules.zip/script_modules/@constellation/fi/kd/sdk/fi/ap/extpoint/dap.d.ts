export declare type IAfterGenerateVoucherExt = $.kd.sdk.fi.ap.extpoint.dap.IAfterGenerateVoucherExt;
export declare const IAfterGenerateVoucherExt: $.kd.sdk.fi.ap.extpoint.dap.IAfterGenerateVoucherExt;
