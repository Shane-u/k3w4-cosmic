export declare type IPushAssignField = $.kd.sdk.fi.ap.extpoint.push.IPushAssignField;
export declare const IPushAssignField: $.kd.sdk.fi.ap.extpoint.push.IPushAssignField;
