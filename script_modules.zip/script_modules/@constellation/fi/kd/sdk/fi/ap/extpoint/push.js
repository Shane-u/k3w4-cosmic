export const IPushAssignField = $.type("kd.sdk.fi.ap.extpoint.push.IPushAssignField");
