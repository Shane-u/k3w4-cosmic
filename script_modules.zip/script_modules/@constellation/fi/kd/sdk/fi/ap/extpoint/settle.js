export const IAfterSettleProcess = $.type("kd.sdk.fi.ap.extpoint.settle.IAfterSettleProcess");
export const IManualSettleCheck = $.type("kd.sdk.fi.ap.extpoint.settle.IManualSettleCheck");
export const IPaySettleWarnFilter = $.type("kd.sdk.fi.ap.extpoint.settle.IPaySettleWarnFilter");
export const IPreSettleFilter = $.type("kd.sdk.fi.ap.extpoint.settle.IPreSettleFilter");
export const ISettleMatchExt = $.type("kd.sdk.fi.ap.extpoint.settle.ISettleMatchExt");
