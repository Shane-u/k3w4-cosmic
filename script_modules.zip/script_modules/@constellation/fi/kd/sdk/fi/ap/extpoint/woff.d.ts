export declare type IAfterWoffProcess = $.kd.sdk.fi.ap.extpoint.woff.IAfterWoffProcess;
export declare const IAfterWoffProcess: $.kd.sdk.fi.ap.extpoint.woff.IAfterWoffProcess;
export declare type IWoffMatchExt = $.kd.sdk.fi.ap.extpoint.woff.IWoffMatchExt;
export declare const IWoffMatchExt: $.kd.sdk.fi.ap.extpoint.woff.IWoffMatchExt;
