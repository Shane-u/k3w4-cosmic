export const ICasPayBillPayCallback = $.type("kd.sdk.fi.ap.extpoint.payapply.ICasPayBillPayCallback");
