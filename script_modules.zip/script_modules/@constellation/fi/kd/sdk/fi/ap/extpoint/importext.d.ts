export declare type IAfterImportDataExt = $.kd.sdk.fi.ap.extpoint.importext.IAfterImportDataExt;
export declare const IAfterImportDataExt: $.kd.sdk.fi.ap.extpoint.importext.IAfterImportDataExt;
