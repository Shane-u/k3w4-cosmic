export const IAfterBizProcess = $.type("kd.sdk.fi.ap.extpoint.list.IAfterBizProcess");
export const IApproverSetting = $.type("kd.sdk.fi.ap.extpoint.list.IApproverSetting");
export const IPayeeBankInfoFilter = $.type("kd.sdk.fi.ap.extpoint.list.IPayeeBankInfoFilter");
