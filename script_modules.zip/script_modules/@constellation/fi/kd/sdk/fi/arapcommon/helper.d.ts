export declare type SettleServiceSDKHelper = $.kd.sdk.fi.arapcommon.helper.SettleServiceSDKHelper;
export declare const SettleServiceSDKHelper: $.kd.sdk.fi.arapcommon.helper.SettleServiceSDKHelper_C;
