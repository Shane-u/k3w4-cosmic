export const SettleServiceSDKHelper = $.type("kd.sdk.fi.arapcommon.helper.SettleServiceSDKHelper");
