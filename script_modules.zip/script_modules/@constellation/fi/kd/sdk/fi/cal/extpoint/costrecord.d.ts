export declare type IQueueTypeMatch = $.kd.sdk.fi.cal.extpoint.costrecord.IQueueTypeMatch;
export declare const IQueueTypeMatch: $.kd.sdk.fi.cal.extpoint.costrecord.IQueueTypeMatch;
