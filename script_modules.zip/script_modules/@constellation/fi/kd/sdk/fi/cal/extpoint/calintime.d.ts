export declare type ICalMoveGroupCost = $.kd.sdk.fi.cal.extpoint.calintime.ICalMoveGroupCost;
export declare const ICalMoveGroupCost: $.kd.sdk.fi.cal.extpoint.calintime.ICalMoveGroupCost;
