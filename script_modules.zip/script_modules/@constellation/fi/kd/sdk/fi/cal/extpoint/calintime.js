export const ICalMoveGroupCost = $.type("kd.sdk.fi.cal.extpoint.calintime.ICalMoveGroupCost");
