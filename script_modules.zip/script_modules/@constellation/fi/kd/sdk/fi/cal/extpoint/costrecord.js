export const IQueueTypeMatch = $.type("kd.sdk.fi.cal.extpoint.costrecord.IQueueTypeMatch");
