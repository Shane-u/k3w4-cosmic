export const CalBalDataSDK = $.type("kd.sdk.fi.cal.extpoint.bal.CalBalDataSDK");
