export declare type CalBalDataSDK = $.kd.sdk.fi.cal.extpoint.bal.CalBalDataSDK;
export declare const CalBalDataSDK: $.kd.sdk.fi.cal.extpoint.bal.CalBalDataSDK_C;
