export declare type IBankInfoF7Service = $.kd.sdk.fi.fr.extpoint.IBankInfoF7Service;
export declare const IBankInfoF7Service: $.kd.sdk.fi.fr.extpoint.IBankInfoF7Service;
