export const IBankInfoF7Service = $.type("kd.sdk.fi.fr.extpoint.IBankInfoF7Service");
