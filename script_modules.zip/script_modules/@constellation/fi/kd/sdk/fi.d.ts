export declare type SdkFiModule = $.kd.sdk.fi.SdkFiModule;
export declare const SdkFiModule: $.kd.sdk.fi.SdkFiModule_C;
