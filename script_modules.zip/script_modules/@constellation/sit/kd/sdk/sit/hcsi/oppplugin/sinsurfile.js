export const ISinSurFileBsedValidatorPlugin = $.type("kd.sdk.sit.hcsi.oppplugin.sinsurfile.ISinSurFileBsedValidatorPlugin");
