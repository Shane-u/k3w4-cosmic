export declare type AfterInsuranceDataListEvent = $.kd.sdk.sit.hcsi.common.events.insurancedata.AfterInsuranceDataListEvent;
export declare const AfterInsuranceDataListEvent: $.kd.sdk.sit.hcsi.common.events.insurancedata.AfterInsuranceDataListEvent_C;
