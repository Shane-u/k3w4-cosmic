export declare type ItemDataEvent = $.kd.sdk.sit.hcsi.common.events.cal.ItemDataEvent;
export declare const ItemDataEvent: $.kd.sdk.sit.hcsi.common.events.cal.ItemDataEvent_C;
