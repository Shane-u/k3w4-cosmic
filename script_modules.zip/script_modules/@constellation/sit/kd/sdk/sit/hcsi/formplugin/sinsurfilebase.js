export const ISinSurFileBaseAddAttributePlugin = $.type("kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseAddAttributePlugin");
export const ISinSurFileBaseImportAddExcelColumnPlugin = $.type("kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseImportAddExcelColumnPlugin");
