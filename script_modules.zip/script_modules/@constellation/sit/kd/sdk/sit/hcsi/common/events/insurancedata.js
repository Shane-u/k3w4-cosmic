export const AfterInsuranceDataListEvent = $.type("kd.sdk.sit.hcsi.common.events.insurancedata.AfterInsuranceDataListEvent");
