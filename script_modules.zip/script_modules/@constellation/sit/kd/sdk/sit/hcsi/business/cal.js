export const IBeforeExportCalPersonExtService = $.type("kd.sdk.sit.hcsi.business.cal.IBeforeExportCalPersonExtService");
