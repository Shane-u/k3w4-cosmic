export declare type ISinSurFileBaseImportAddAttributeService = $.kd.sdk.sit.hcsi.service.sinsurfilebase.ISinSurFileBaseImportAddAttributeService;
export declare const ISinSurFileBaseImportAddAttributeService: $.kd.sdk.sit.hcsi.service.sinsurfilebase.ISinSurFileBaseImportAddAttributeService;
export declare type SinSurFileBaseHelper = $.kd.sdk.sit.hcsi.service.sinsurfilebase.SinSurFileBaseHelper;
export declare const SinSurFileBaseHelper: $.kd.sdk.sit.hcsi.service.sinsurfilebase.SinSurFileBaseHelper_C;
