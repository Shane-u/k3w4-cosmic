export declare type ISinSurFileBaseAddAttributeService = $.kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseAddAttributeService;
export declare const ISinSurFileBaseAddAttributeService: $.kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseAddAttributeService;
export declare type ISinSurFileBaseHisChangeService = $.kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseHisChangeService;
export declare const ISinSurFileBaseHisChangeService: $.kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseHisChangeService;
