export declare type IInsuranceDataSynExtService = $.kd.sdk.sit.hcsi.business.extpoint.IInsuranceDataSynExtService;
export declare const IInsuranceDataSynExtService: $.kd.sdk.sit.hcsi.business.extpoint.IInsuranceDataSynExtService;
export declare type ITruncationDealExtService = $.kd.sdk.sit.hcsi.business.extpoint.ITruncationDealExtService;
export declare const ITruncationDealExtService: $.kd.sdk.sit.hcsi.business.extpoint.ITruncationDealExtService;
