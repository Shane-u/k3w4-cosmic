export declare type SinSurFileHelper = $.kd.sdk.sit.hcsi.service.sinsurfile.SinSurFileHelper;
export declare const SinSurFileHelper: $.kd.sdk.sit.hcsi.service.sinsurfile.SinSurFileHelper_C;
