export const SinSurFileHelper = $.type("kd.sdk.sit.hcsi.service.sinsurfile.SinSurFileHelper");
