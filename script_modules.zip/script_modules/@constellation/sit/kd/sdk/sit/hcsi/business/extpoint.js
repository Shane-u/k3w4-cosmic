export const IInsuranceDataSynExtService = $.type("kd.sdk.sit.hcsi.business.extpoint.IInsuranceDataSynExtService");
export const ITruncationDealExtService = $.type("kd.sdk.sit.hcsi.business.extpoint.ITruncationDealExtService");
