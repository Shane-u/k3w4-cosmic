export declare type IBeforeExportCalPersonExtService = $.kd.sdk.sit.hcsi.business.cal.IBeforeExportCalPersonExtService;
export declare const IBeforeExportCalPersonExtService: $.kd.sdk.sit.hcsi.business.cal.IBeforeExportCalPersonExtService;
