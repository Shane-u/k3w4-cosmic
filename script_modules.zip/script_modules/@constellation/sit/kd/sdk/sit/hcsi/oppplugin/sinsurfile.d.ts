export declare type ISinSurFileBsedValidatorPlugin = $.kd.sdk.sit.hcsi.oppplugin.sinsurfile.ISinSurFileBsedValidatorPlugin;
export declare const ISinSurFileBsedValidatorPlugin: $.kd.sdk.sit.hcsi.oppplugin.sinsurfile.ISinSurFileBsedValidatorPlugin;
