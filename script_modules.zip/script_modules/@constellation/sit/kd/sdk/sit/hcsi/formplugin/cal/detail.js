export const ICalPersonListAutoSumPlugin = $.type("kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListAutoSumPlugin");
export const ICalPersonListDisplayPlugin = $.type("kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListDisplayPlugin");
