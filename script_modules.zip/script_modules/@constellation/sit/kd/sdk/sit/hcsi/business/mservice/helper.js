export const CalResultServiceHelper = $.type("kd.sdk.sit.hcsi.business.mservice.helper.CalResultServiceHelper");
