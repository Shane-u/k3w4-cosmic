export const ISinSurFileBaseAddAttributeService = $.type("kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseAddAttributeService");
export const ISinSurFileBaseHisChangeService = $.type("kd.sdk.sit.hcsi.oppplugin.sinsurfilebase.ISinSurFileBaseHisChangeService");
