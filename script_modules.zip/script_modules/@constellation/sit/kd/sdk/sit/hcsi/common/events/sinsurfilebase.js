export const SinSurFileBaseAddAttributeEvent = $.type("kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddAttributeEvent");
export const SinSurFileBaseAddPageAttributeEvent = $.type("kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddPageAttributeEvent");
export const SinSurFileBaseHisChangeEvent = $.type("kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseHisChangeEvent");
export const SinSurFileBaseImportAddExcelColumnEvent = $.type("kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseImportAddExcelColumnEvent");
