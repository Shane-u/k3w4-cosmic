export declare type ISinSurFileBaseAddAttributePlugin = $.kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseAddAttributePlugin;
export declare const ISinSurFileBaseAddAttributePlugin: $.kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseAddAttributePlugin;
export declare type ISinSurFileBaseImportAddExcelColumnPlugin = $.kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseImportAddExcelColumnPlugin;
export declare const ISinSurFileBaseImportAddExcelColumnPlugin: $.kd.sdk.sit.hcsi.formplugin.sinsurfilebase.ISinSurFileBaseImportAddExcelColumnPlugin;
