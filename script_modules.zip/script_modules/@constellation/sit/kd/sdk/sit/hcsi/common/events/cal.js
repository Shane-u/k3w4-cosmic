export const ItemDataEvent = $.type("kd.sdk.sit.hcsi.common.events.cal.ItemDataEvent");
