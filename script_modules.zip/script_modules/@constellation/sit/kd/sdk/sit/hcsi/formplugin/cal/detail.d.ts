export declare type ICalPersonListAutoSumPlugin = $.kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListAutoSumPlugin;
export declare const ICalPersonListAutoSumPlugin: $.kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListAutoSumPlugin;
export declare type ICalPersonListDisplayPlugin = $.kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListDisplayPlugin;
export declare const ICalPersonListDisplayPlugin: $.kd.sdk.sit.hcsi.formplugin.cal.detail.ICalPersonListDisplayPlugin;
