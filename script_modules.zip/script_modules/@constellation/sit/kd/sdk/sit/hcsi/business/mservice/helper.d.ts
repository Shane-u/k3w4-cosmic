export declare type CalResultServiceHelper = $.kd.sdk.sit.hcsi.business.mservice.helper.CalResultServiceHelper;
export declare const CalResultServiceHelper: $.kd.sdk.sit.hcsi.business.mservice.helper.CalResultServiceHelper_C;
