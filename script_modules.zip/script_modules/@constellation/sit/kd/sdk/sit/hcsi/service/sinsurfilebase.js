export const ISinSurFileBaseImportAddAttributeService = $.type("kd.sdk.sit.hcsi.service.sinsurfilebase.ISinSurFileBaseImportAddAttributeService");
export const SinSurFileBaseHelper = $.type("kd.sdk.sit.hcsi.service.sinsurfilebase.SinSurFileBaseHelper");
