export declare type SinSurFileBaseAddAttributeEvent = $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddAttributeEvent;
export declare const SinSurFileBaseAddAttributeEvent: $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddAttributeEvent_C;
export declare type SinSurFileBaseAddPageAttributeEvent = $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddPageAttributeEvent;
export declare const SinSurFileBaseAddPageAttributeEvent: $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseAddPageAttributeEvent_C;
export declare type SinSurFileBaseHisChangeEvent = $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseHisChangeEvent;
export declare const SinSurFileBaseHisChangeEvent: $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseHisChangeEvent_C;
export declare type SinSurFileBaseImportAddExcelColumnEvent = $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseImportAddExcelColumnEvent;
export declare const SinSurFileBaseImportAddExcelColumnEvent: $.kd.sdk.sit.hcsi.common.events.sinsurfilebase.SinSurFileBaseImportAddExcelColumnEvent_C;
