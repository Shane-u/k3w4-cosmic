export declare type TaxPersonQueryService = $.kd.sdk.sit.iit.business.tax.person.TaxPersonQueryService;
export declare const TaxPersonQueryService: $.kd.sdk.sit.iit.business.tax.person.TaxPersonQueryService;
