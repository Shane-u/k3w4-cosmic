export const TaxPersonQueryService = $.type("kd.sdk.sit.iit.business.tax.person.TaxPersonQueryService");
