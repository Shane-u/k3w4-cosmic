export declare type TaxFileServiceHelper = $.kd.sdk.sit.iit.business.mservice.helper.TaxFileServiceHelper;
export declare const TaxFileServiceHelper: $.kd.sdk.sit.iit.business.mservice.helper.TaxFileServiceHelper_C;
