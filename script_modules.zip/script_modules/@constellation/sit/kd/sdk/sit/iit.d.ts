export declare type SdkIitModule = $.kd.sdk.sit.iit.SdkIitModule;
export declare const SdkIitModule: $.kd.sdk.sit.iit.SdkIitModule_C;
