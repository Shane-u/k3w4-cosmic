export const SdkHcsiModule = $.type("kd.sdk.sit.hcsi.SdkHcsiModule");
