export declare type SdkHcsiModule = $.kd.sdk.sit.hcsi.SdkHcsiModule;
export declare const SdkHcsiModule: $.kd.sdk.sit.hcsi.SdkHcsiModule_C;
