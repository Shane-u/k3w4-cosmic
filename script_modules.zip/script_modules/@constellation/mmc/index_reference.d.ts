/// <reference types="./kd/sdk/mmc/mrp/extpoint" />
/// <reference types="./kd/sdk/mmc/mrp" />
/// <reference types="./index" />
/// <reference types="./kd/sdk/mmc/mrp/framework/res" />
