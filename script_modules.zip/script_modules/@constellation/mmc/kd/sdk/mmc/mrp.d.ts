/// <reference types="../../../index" />
export declare type IMRPSDKEnv = $.kd.sdk.mmc.mrp.IMRPSDKEnv;
export declare const IMRPSDKEnv: $.kd.sdk.mmc.mrp.IMRPSDKEnv;
export declare type SdkMmcMrpModule = $.kd.sdk.mmc.mrp.SdkMmcMrpModule;
export declare const SdkMmcMrpModule: $.kd.sdk.mmc.mrp.SdkMmcMrpModule_C;
