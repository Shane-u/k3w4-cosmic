export const IMRPSDKEnv = $.type("kd.sdk.mmc.mrp.IMRPSDKEnv");
export const SdkMmcMrpModule = $.type("kd.sdk.mmc.mrp.SdkMmcMrpModule");
