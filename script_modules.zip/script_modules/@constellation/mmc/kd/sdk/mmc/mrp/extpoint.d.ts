/// <reference types="../../../../index" />
export declare type IMRPCalcNetDemandPlugin = $.kd.sdk.mmc.mrp.extpoint.IMRPCalcNetDemandPlugin;
export declare const IMRPCalcNetDemandPlugin: $.kd.sdk.mmc.mrp.extpoint.IMRPCalcNetDemandPlugin;
export declare type IMRPClearHistoryDataPlugin = $.kd.sdk.mmc.mrp.extpoint.IMRPClearHistoryDataPlugin;
export declare const IMRPClearHistoryDataPlugin: $.kd.sdk.mmc.mrp.extpoint.IMRPClearHistoryDataPlugin;
export declare type IMRPInitBomDataPlugin = $.kd.sdk.mmc.mrp.extpoint.IMRPInitBomDataPlugin;
export declare const IMRPInitBomDataPlugin: $.kd.sdk.mmc.mrp.extpoint.IMRPInitBomDataPlugin;
export declare type IMRPMaterialPlanPlugin = $.kd.sdk.mmc.mrp.extpoint.IMRPMaterialPlanPlugin;
export declare const IMRPMaterialPlanPlugin: $.kd.sdk.mmc.mrp.extpoint.IMRPMaterialPlanPlugin;
