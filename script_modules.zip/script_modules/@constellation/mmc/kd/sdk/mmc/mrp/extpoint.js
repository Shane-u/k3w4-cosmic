export const IMRPCalcNetDemandPlugin = $.type("kd.sdk.mmc.mrp.extpoint.IMRPCalcNetDemandPlugin");
export const IMRPClearHistoryDataPlugin = $.type("kd.sdk.mmc.mrp.extpoint.IMRPClearHistoryDataPlugin");
export const IMRPInitBomDataPlugin = $.type("kd.sdk.mmc.mrp.extpoint.IMRPInitBomDataPlugin");
export const IMRPMaterialPlanPlugin = $.type("kd.sdk.mmc.mrp.extpoint.IMRPMaterialPlanPlugin");
