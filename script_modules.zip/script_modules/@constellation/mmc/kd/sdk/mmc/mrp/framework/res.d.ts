/// <reference types="../../../../../index" />
export declare type IResModelDataTable = $.kd.sdk.mmc.mrp.framework.res.IResModelDataTable;
export declare const IResModelDataTable: $.kd.sdk.mmc.mrp.framework.res.IResModelDataTable;
