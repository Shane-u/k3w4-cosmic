export const IResModelDataTable = $.type("kd.sdk.mmc.mrp.framework.res.IResModelDataTable");
